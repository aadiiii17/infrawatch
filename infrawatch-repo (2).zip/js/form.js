/* form.js
 * Inspection checklist form.
 */

function setFormRating(field, val){ S.formAnswers[field]=val; render(); }

function screenForm(){
  let sections = '';
  for(const [sec, fields] of Object.entries(FORM_FIELDS)){
    sections += `<div class="section-label" style="margin-top:22px;">${t(FORM_SECTION_KEY[sec])}</div><div class="card">`;
    fields.forEach((f,i)=>{
      const val = S.formAnswers[f];
      sections += `<div style="${i>0?'margin-top:14px; padding-top:14px; border-top:1px solid var(--border);':''}">
        <div style="font-size:13px; font-weight:600; margin-bottom:8px;">${t(FORM_FIELD_KEY[f])}</div>
        <div class="chip-row">
          ${['Good','Fair','Poor','Critical'].map(o=>`<span class="chip ${val===o?'sel-'+o.toLowerCase():''}" onclick="setFormRating('${f}','${o}')">${t(RATING_KEY[o])}</span>`).join('')}
        </div>
      </div>`;
    });
    sections += `</div>`;
  }
  return `<div class="screen-body">
    ${header(t('inspectionChecklist'), S.activeSite.name, "go('gps')")}
    <div class="content">
      ${sections}
      <div class="section-label" style="margin-top:22px;">${t('remarksAndMeasurements')}</div>
      <div class="field"><label>${t('remarks')}</label><textarea rows="3" placeholder="${t('addInspectorRemarks')}"></textarea></div>
      <div class="field"><label>${t('measurementMm')}</label><input type="number" placeholder="e.g. 12.5" /></div>
    </div>
    <div class="fab-start">
      <div class="btn-row">
        <button class="btn btn-outline" onclick="showToast(t('draftSaved'))">${t('saveDraft')}</button>
        <button class="btn btn-primary" onclick="go('camera')">${t('next')}</button>
      </div>
    </div>
  </div>`;
}
