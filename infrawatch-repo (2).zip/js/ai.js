/* ai.js
 * Simulated AI defect analysis, defect details and saving findings.
 */

function getAiPhoto(){
  // Use the most recently captured real photo (from the live camera) if one exists.
  const withThumb = S.evidence.filter(e=>e.thumb);
  return withThumb.length ? withThumb[withThumb.length-1].thumb : null;
}

function screenAI(){
  const photo = getAiPhoto();
  const photoStyle = photo ? `style="background-image:url('${photo}'); background-size:cover; background-position:center;"` : '';
  if(!S.aiAnalyzed){
    S.aiAnalyzed = true;
    setTimeout(()=>{ render(); }, 1600);
    return `<div class="screen-body">
      ${header(t('aiAnalysis'), S.activeSite.id, "go('camera')")}
      <div class="content" style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:60%; gap:16px;">
        <div class="ai-image" style="width:100%;" ${photoStyle}><div class="scan-line"></div></div>
        <div style="font-weight:700;">${t('analyzingEvidence')}</div>
        <div style="font-size:12px; color:var(--muted);">${t('runningModel')}</div>
        ${!photo ? `<div style="font-size:11px; color:var(--muted); text-align:center; padding:0 20px;">${t('noLivePhoto')}</div>` : ''}
      </div>
    </div>`;
  }
  S.aiFinding = {type:'Surface Crack', confidence:91, severity:'HIGH'};
  return `<div class="screen-body">
    ${header(t('aiInspectionResult'), S.activeSite.id, "go('camera')")}
    <div class="content">
      <div class="ai-image" ${photoStyle}>
        <div class="bbox" style="top:38%; left:30%; width:34%; height:26%;">
          <div class="bbox-tag">${t('surfaceCrack')} · 91%</div>
        </div>
      </div>
      <div class="banner info" style="margin-top:14px;">${t('aiBanner')}</div>
      <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
          <div>
            <div style="font-size:11px; color:var(--muted); font-weight:700;">${t('defectDetected')}</div>
            <div style="font-size:17px; font-weight:800; margin-top:2px;">${t('surfaceCrack')}</div>
          </div>
          <span class="badge critical">${severityLabel('High').toUpperCase()}</span>
        </div>
        <div style="margin-top:12px;">
          <div style="display:flex; justify-content:space-between; font-size:12px;"><span>${t('confidence')}</span><span class="num" style="font-weight:700;">91%</span></div>
          <div class="confidence-bar"><div class="confidence-fill" style="width:91%; background:var(--critical);"></div></div>
        </div>
        <div class="divider"></div>
        <div style="font-size:12px; font-weight:700; color:var(--muted); margin-bottom:8px;">${t('otherPossibleFindings')}</div>
        <div style="display:flex; justify-content:space-between; font-size:12.5px; margin-bottom:6px;"><span>${t('corrosionFinding')}</span><span class="num">72%</span></div>
        <div class="confidence-bar" style="margin-bottom:10px;"><div class="confidence-fill" style="width:72%; background:var(--warning);"></div></div>
        <div style="display:flex; justify-content:space-between; font-size:12.5px; margin-bottom:6px;"><span>${t('surfaceDamageFinding')}</span><span class="num">64%</span></div>
        <div class="confidence-bar"><div class="confidence-fill" style="width:64%; background:var(--info);"></div></div>
      </div>

      <div class="section-label">${t('recommendedAction')}</div>
      <div class="card" style="font-size:12.5px; color:var(--muted);">
        🧭 <b style="color:var(--ink);">${t('scheduleTechnical')}</b><br/>
        ${t('otherOptions')}
      </div>
    </div>
    <div class="fab-start">
      <div class="btn-row">
        <button class="btn btn-ghost" style="border:1.5px solid var(--border);" onclick="aiAction('reject')">${t('reject')}</button>
        <button class="btn btn-outline" onclick="aiAction('edit')">${t('edit')}</button>
        <button class="btn btn-primary" onclick="aiAction('confirm')">${t('confirm')}</button>
      </div>
    </div>
  </div>`;
}

function aiAction(action){
  if(action==='reject'){
    S.findings.push({type:'Surface Crack', severity:'HIGH', confidence:91, status:'rejected'});
    showToast(t('findingRejected')); go('camera'); return;
  }
  S.pendingFinding = {type:'Surface Crack', severity:'HIGH', confidence:91, edited: action==='edit'};
  go('defect');
}

function screenDefect(){
  const f = S.pendingFinding || {type:'Surface Crack', severity:'HIGH', confidence:91};
  return `<div class="screen-body">
    ${header(t('defectDetails'), S.activeSite.id, "go('ai')")}
    <div class="content">
      <div class="card">
        <div class="check-row"><span>${t('defectType')}</span><span style="margin-left:auto; font-weight:700;">${f.type==='Surface Crack'?t('surfaceCrack'):f.type}</span></div>
        <div class="check-row"><span>${t('severity')}</span><span style="margin-left:auto;"><span class="badge critical">${severityLabel('High').toUpperCase()}</span></span></div>
        <div class="check-row" style="border-bottom:none;"><span>${t('confidence')}</span><span style="margin-left:auto; font-weight:700;">${f.confidence}%</span></div>
      </div>
      <div class="section-label">${t('description')}</div>
      <div class="card" style="font-size:12.5px; color:var(--muted);">${t('crackDescription')}</div>
      <div class="section-label">${t('recommendedAction')}</div>
      <div class="card" style="font-size:12.5px; color:var(--muted);">${t('technicalRecommended')}</div>

      <div class="field" style="margin-top:16px;"><label>${t('addRemarks')}</label><textarea rows="2" placeholder="${t('inspectorRemarksPh')}"></textarea></div>
      <div class="field"><label>${t('addMeasurement')}</label><input type="number" placeholder="e.g. 8.4" /></div>
      <div class="field">
        <label>${t('assignPriority')}</label>
        <select><option>${severityLabel('Critical')}</option><option>${severityLabel('High')}</option><option selected>${severityLabel('Medium')}</option><option>${severityLabel('Low')}</option></select>
      </div>
      <button class="chip" style="margin-bottom:8px;">${t('addAnotherPhoto')}</button>
    </div>
    <div class="fab-start">
      <button class="btn btn-primary" onclick="saveFinding()">${t('saveFinding')}</button>
    </div>
  </div>`;
}

function saveFinding(){
  S.findings.push({...(S.pendingFinding||{type:'Surface Crack',severity:'HIGH',confidence:91}), status:'confirmed'});
  showToast(t('findingSaved'));
  S.aiAnalyzed = false;
  go('review');
}
