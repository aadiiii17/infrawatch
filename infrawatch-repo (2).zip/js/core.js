/* core.js
 * Core helpers: escaping, toasts, navigation (go / setNavTab), app-mode switching and the render() dispatcher.
 */

function esc(s){return s;}

function badgeClass(p){return {High:'high',Critical:'critical',Medium:'medium',Warning:'warning',Low:'low',Success:'success'}[p] || 'neutral';}

function showToast(msg, ms=2200){
  S.toast = msg; render();
  setTimeout(()=>{ S.toast=null; render(); }, ms);
}

function go(screen){ S.screen = screen; render(); document.getElementById('phone-screen').scrollTop=0; }

function setNavTab(tab){ S.navTab = tab; S.screen = tab; render(); }

function setAppMode(mode){
  S.appMode = mode;
  document.getElementById('phone-wrap').style.display = mode==='inspector' ? 'block':'none';
  document.getElementById('admin-phone-wrap').style.display = mode==='admin' ? 'block':'none';
  render();
}

function render(){
  if(S.appMode==='inspector'){
    const leavingCamera = window.lastInspectorScreen==='camera' && S.screen!=='camera';
    const leavingSiteDetail = window.lastInspectorScreen==='siteDetail' && S.screen!=='siteDetail';
    if(leavingSiteDetail && S.qrModal){ stopQrScanner(); S.qrModal = false; }
    document.getElementById('phone-screen').innerHTML = renderInspector();
    if(leavingCamera){ stopCameraPreview(); }
    if(S.screen==='gps'){
      setTimeout(initGpsMap, 0);
      if(S.gpsStatus==='idle'){ requestGpsLocation(); }
    }
    if(S.screen==='camera'){ setTimeout(initCameraPreview, 0); }
    window.lastInspectorScreen = S.screen;
  } else {
    document.getElementById('admin-phone-screen').innerHTML = renderAdmin();
    if(S.adminLoggedIn && S.adminScreen==='dashboard'){ setTimeout(()=>initAdminMap('admin-map-dashboard'), 0); }
    if(S.adminLoggedIn && S.adminScreen==='map'){ setTimeout(()=>initAdminMap('admin-map-full'), 0); }
  }
}

function showToastQuick(){}

function showToastAdmin(msg){
  const el = document.createElement('div');
  el.textContent = msg;
  el.style.cssText='position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#0F172A;color:#fff;padding:11px 18px;border-radius:12px;font-size:13px;font-weight:500;z-index:999;box-shadow:0 10px 28px rgba(15,23,42,.3);';
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), 2200);
}

function escHtml(x){ return String(x).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
