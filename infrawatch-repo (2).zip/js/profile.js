/* profile.js
 * Profile screen: editable details and photo, language, notifications, dark mode, local persistence.
 */

function initialsOf(name){
  const parts = String(name||'').trim().split(/\s+/).filter(Boolean);
  if(!parts.length) return '?';
  return (parts[0][0] + (parts.length>1 ? parts[parts.length-1][0] : '')).toUpperCase();
}

function agoText(n, unit){
  if(S.lang==='hi') return `${n} ${unit==='h' ? 'घंटे' : 'दिन'} पहले`;
  return `${n}${unit} ago`;
}

function persistProfile(){
  try{ localStorage.setItem('infrawatch.profile', JSON.stringify({ profile:S.profile, notifOn:S.notifOn, darkMode:S.darkMode, lang:S.lang })); }catch(e){}
}

function loadProfile(){
  try{
    const raw = localStorage.getItem('infrawatch.profile');
    if(raw){
      const d = JSON.parse(raw);
      if(d.profile) S.profile = Object.assign(S.profile, d.profile);
      if(typeof d.notifOn==='boolean') S.notifOn = d.notifOn;
      if(typeof d.darkMode==='boolean') S.darkMode = d.darkMode;
      if(d.lang==='en' || d.lang==='hi') S.lang = d.lang;
    }
  }catch(e){}
  document.body.classList.toggle('dark', !!S.darkMode);
}

function profileAvatar(size){
  const p = S.profile;
  const base = `width:${size}px;height:${size}px;`;
  if(p.photo){ return `<div class="avatar" style="${base} background-image:url('${p.photo}');"></div>`; }
  return `<div class="avatar" style="${base} font-size:${Math.round(size*0.34)}px;">${escHtml(initialsOf(p.name))}</div>`;
}

function startEditProfile(){ S.profileEditing = true; render(); }

function cancelEditProfile(){ S.profileEditing = false; render(); }

function saveProfile(){
  const name = document.getElementById('pf-name').value.trim();
  const phone = document.getElementById('pf-phone').value.trim();
  const email = document.getElementById('pf-email').value.trim();
  if(!name){ showToast(t('nameRequired')); return; }
  const digits = phone.replace(/\D/g,'');
  if(digits.length < 10 || digits.length > 13){ showToast(t('phoneInvalid')); return; }
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ showToast(t('emailInvalid')); return; }
  S.profile.name = name; S.profile.phone = phone; S.profile.email = email;
  S.profileEditing = false;
  persistProfile();
  showToast(t('profileSaved'));
}

function handleProfilePhoto(input){
  const f = input.files && input.files[0];
  input.value = '';
  if(!f) return;
  const img = new Image();
  const url = URL.createObjectURL(f);
  img.onload = ()=>{
    const sz = 256, c = document.createElement('canvas');
    c.width = c.height = sz;
    const m = Math.min(img.width, img.height);
    c.getContext('2d').drawImage(img, (img.width-m)/2, (img.height-m)/2, m, m, 0, 0, sz, sz);
    URL.revokeObjectURL(url);
    S.profile.photo = c.toDataURL('image/jpeg', 0.85);
    persistProfile(); render();
  };
  img.onerror = ()=>{ URL.revokeObjectURL(url); showToast(t('photoError')); };
  img.src = url;
}

function removeProfilePhoto(){ S.profile.photo = null; persistProfile(); render(); }

function setLang(l){ S.lang = l; persistProfile(); render(); }

function toggleNotif(){ S.notifOn = !S.notifOn; persistProfile(); render(); }

function toggleDark(){
  S.darkMode = !S.darkMode;
  document.body.classList.toggle('dark', S.darkMode);
  persistProfile(); render();
}

function screenProfile(){
  const p = S.profile;
  const editing = S.profileEditing;
  const completed = 128, resolved = 54;
  const acts = [
    ['✅','actSubmitted','SITE-024',agoText(2,'h')],
    ['📸','actEvidence','SITE-017',agoText(3,'h')],
    ['📍','actCheckin','SITE-017',agoText(3,'h')],
    ['🛠️','actResolved','SITE-009',agoText(1,'d')],
  ];
  const awards = [['🏅','badge100'],['⚡','badgeFast'],['🎯','badgeZero'],['🛡️','badgeSafety']];

  return `<div class="screen-body">
    ${header(t('profile'))}
    <div class="content">
      <input type="file" id="profile-photo-input" accept="image/*" style="display:none;" onchange="handleProfilePhoto(this)" />
      <div class="profile-hero">
        <div style="display:flex; gap:16px; align-items:center; position:relative; z-index:1;">
          <div class="avatar-wrap" onclick="document.getElementById('profile-photo-input').click()">
            ${profileAvatar(84)}<span class="avatar-cam">📷</span>
          </div>
          <div style="flex:1; min-width:0;">
            <h2 class="profile-name">${escHtml(p.name)}</h2>
            <div class="profile-meta">EMP-2291 · ${t('structuralTeam')}</div>
            <span class="badge info" style="margin-top:8px;">● ${t('onField')}</span>
          </div>
        </div>
        <div style="display:flex; gap:8px; margin-top:14px; position:relative; z-index:1;">
          ${editing ? '' : `<button class="btn btn-outline btn-sm" style="flex:1;" onclick="startEditProfile()">✏️ ${t('editProfile')}</button>`}
          <button class="btn btn-outline btn-sm" style="flex:1;" onclick="document.getElementById('profile-photo-input').click()">📷 ${t('changePhoto')}</button>
          ${p.photo ? `<button class="btn btn-outline btn-sm" onclick="removeProfilePhoto()" title="${t('removePhoto')}">🗑️</button>` : ''}
        </div>
      </div>

      <div class="stat-grid" style="grid-template-columns:repeat(3,1fr);">
        <div class="stat"><div class="n">${completed}</div><div class="l">${t('completedInspections')}</div></div>
        <div class="stat"><div class="n">${resolved}</div><div class="l">${t('issuesResolved')}</div></div>
        <div class="stat"><div class="n">96%</div><div class="l">${t('onTimeRate')}</div></div>
      </div>

      <div class="section-label">${t('contactInfo')}</div>
      ${editing ? `<div class="card">
        <div class="field"><label>${t('fullName')}</label><input id="pf-name" type="text" value="${escHtml(p.name)}" /></div>
        <div class="field"><label>${t('phoneNumber')}</label><input id="pf-phone" type="tel" value="${escHtml(p.phone)}" /></div>
        <div class="field"><label>${t('emailAddress')}</label><input id="pf-email" type="email" value="${escHtml(p.email)}" /></div>
        <div class="btn-row">
          <button class="btn btn-outline btn-sm" onclick="cancelEditProfile()">${t('cancel')}</button>
          <button class="btn btn-primary btn-sm" onclick="saveProfile()">${t('save')}</button>
        </div>
      </div>` : `<div class="card">
        <div class="check-row"><span>📞</span><span style="font-weight:800;">${escHtml(p.phone)}</span></div>
        <div class="check-row"><span>✉️</span><span style="font-weight:800; word-break:break-all;">${escHtml(p.email)}</span></div>
        <div class="check-row"><span>🏢</span><span>${t('department')}</span><span style="margin-left:auto; font-weight:800;">${t('civilInfra')}</span></div>
        <div class="check-row" style="border-bottom:none;"><span>🧭</span><span>${t('assignedRegion')}</span><span style="margin-left:auto; font-weight:800;">${t('northZone')}</span></div>
      </div>`}

      <div class="section-label">${t('badgesTitle')}</div>
      <div class="award-grid">
        ${awards.map(a=>`<div class="award"><div class="award-emoji">${a[0]}</div>${t(a[1])}</div>`).join('')}
      </div>

      <div class="section-label">${t('recentActivity')}</div>
      <div class="card" style="padding:6px 16px;">
        ${acts.map((a,i)=>`<div class="check-row" ${i===acts.length-1?'style="border-bottom:none;"':''}>
          <span style="font-size:18px;">${a[0]}</span>
          <span style="flex:1;"><b>${t(a[1])}</b> · ${a[2]}</span>
          <span style="color:var(--muted); font-size:11.5px; white-space:nowrap;">${a[3]}</span>
        </div>`).join('')}
      </div>

      <div class="section-label">${t('settings')}</div>
      <div class="card" style="padding:0;">
        <div class="check-row" style="padding:13px 16px;"><span>🌐 ${t('language')}</span>
          <span style="margin-left:auto; display:flex; gap:6px;">
            <span class="filter-pill ${S.lang==='en'?'active':''}" onclick="setLang('en')">English</span>
            <span class="filter-pill ${S.lang==='hi'?'active':''}" onclick="setLang('hi')">हिन्दी</span>
          </span></div>
        <div class="check-row" style="padding:13px 16px;"><span>🔔 ${t('notifications')}</span>
          <span style="margin-left:auto;"><div class="switch ${S.notifOn?'on':''}" onclick="toggleNotif()"></div></span></div>
        <div class="check-row" style="padding:13px 16px;"><span>🌙 ${t('darkMode')}</span>
          <span style="margin-left:auto;"><div class="switch ${S.darkMode?'on':''}" onclick="toggleDark()"></div></span></div>
        <div class="check-row" style="padding:13px 16px; border-bottom:none; cursor:pointer;" onclick="inspectorLogout()"><span style="color:var(--critical); font-weight:800;">⎋ ${t('logout')}</span><span style="margin-left:auto;">→</span></div>
      </div>
    </div>
  </div>`;
}
