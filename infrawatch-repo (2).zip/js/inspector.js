/* inspector.js
 * Inspector app shell and main screens: dashboard, site list, site detail, issues, notifications.
 */

function renderInspector(){
  const statusbar = `<div class="statusbar"><span class="statusbar-clock">--:--</span><span>●●● 5G  <span class="statusbar-battery">🔋</span></span></div>`;
  let body = '';
  switch(S.screen){
    case 'splash': body = screenSplash(); break;
    case 'login': body = screenLogin(); break;
    case 'home': body = screenDashboard(); break;
    case 'inspections': body = screenInspectionList(); break;
    case 'issues': body = screenIssues(); break;
    case 'notifications': body = screenNotifications(); break;
    case 'profile': body = screenProfile(); break;
    case 'siteDetail': body = screenSiteDetail(); break;
    case 'gps': body = screenGPS(); break;
    case 'form': body = screenForm(); break;
    case 'camera': body = screenCamera(); break;
    case 'ai': body = screenAI(); break;
    case 'defect': body = screenDefect(); break;
    case 'review': body = screenReview(); break;
    case 'success': body = screenSuccess(); break;
    case 'reinspect': body = screenReinspect(); break;
    case 'report': body = screenReport(); break;
    default: body = screenDashboard();
  }
  const showNav = ['home','inspections','issues','notifications','profile'].includes(S.screen);
  const toast = S.toast ? `<div class="toast">🔔 ${S.toast}</div>` : '';
  return statusbar + toast + body + (showNav ? bottomNav() : '');
}

function bottomNav(){
  const items = [
    {id:'home', icon:'🏠', label:t('nav_home')},
    {id:'inspections', icon:'📋', label:t('nav_inspections')},
    {id:'issues', icon:'🛠️', label:t('nav_issues')},
    {id:'notifications', icon:'🔔', label:t('nav_alerts')},
    {id:'profile', icon:'👤', label:t('nav_profile')},
  ];
  return `<div class="bottomnav">${items.map(i=>`
    <button class="nav-item ${S.navTab===i.id?'active':''}" onclick="setNavTab('${i.id}')">
      <span class="nav-icon">${i.icon}</span>${i.label}
    </button>`).join('')}</div>`;
}

function header(title, sub, back){
  return `<div class="app-header">
    ${back ? `<button class="backbtn" onclick="${back}">←</button>` : ''}
    <div><h2>${title}</h2>${sub?`<div class="sub">${sub}</div>`:''}</div>
  </div>`;
}

function screenDashboard(){
  const lang = T[S.lang];
  return `<div class="screen-body">
    <div class="app-header" style="justify-content:space-between;">
      <div>
        <h2>${lang.goodMorning} 👋</h2>
        <div class="sub">Rahul Sharma · ${t('structuralTeam')}</div>
      </div>
      <div style="display:flex; gap:8px; align-items:center;">
        <button class="chip" style="padding:6px 10px;" onclick="toggleLang()">${S.lang==='en'?'EN':'हिं'}</button>
        <button class="chip" style="padding:6px 10px;" onclick="toggleOffline()">${S.offline?'📡 '+t('offline'):'📶 '+t('online')}</button>
      </div>
    </div>
    <div class="content">
      ${S.offline ? offlineBanner() : ''}
      <div class="stat-grid">
        <div class="stat"><div class="n">8</div><div class="l">${t('statAssigned')}</div></div>
        <div class="stat warning"><div class="n">3</div><div class="l">${t('statPending')}</div></div>
        <div class="stat success"><div class="n">5</div><div class="l">${t('statCompleted')}</div></div>
        <div class="stat critical"><div class="n">2</div><div class="l">${t('statCritical')}</div></div>
      </div>

      <div class="section-label">${lang.todaysInspections} <span class="link" onclick="setNavTab('inspections')">${t('viewAll')}</span></div>
      ${siteCard(SITES[0])}
      ${siteCard(SITES[1])}

      <div class="section-label">${t('inspectionIntegrity')} <span class="link" onclick="go('review')">${t('details')}</span></div>
      <div class="card" style="display:flex; align-items:center; gap:16px;">
        ${integrityRing(96)}
        <div style="font-size:12px; color:var(--muted); line-height:1.5;">
          ${t('integrityDesc')}
        </div>
      </div>
    </div>
    <div class="fab-start">
      <button class="btn btn-accent" onclick="startFlow(SITES[0])">📍 ${t('startInspection')}</button>
    </div>
  </div>`;
}

function offlineBanner(){
  if(S.syncing){
    return `<div class="banner ok">${t('syncedBanner')}</div>`;
  }
  return `<div class="banner warn">${t('offlineBanner')} <b>4 ${t('records')}</b></div>`;
}

function toggleOffline(){
  S.offline = !S.offline;
  if(!S.offline){
    S.syncing = true; render();
    setTimeout(()=>{ S.syncing=false; showToast(t('syncedToast')); }, 1800);
  } else { render(); }
}

function toggleLang(){ S.lang = S.lang==='en' ? 'hi' : 'en'; render(); }

function siteCard(site){
  return `<div class="task-card" onclick='openSite(${JSON.stringify(site.id)})'>
    <div class="task-top">
      <div class="task-title">${site.name}</div>
      <span class="badge ${badgeClass(site.priority)}">${priorityLabel(site.priority)}</span>
    </div>
    <div class="task-meta">📍 ${site.location} &nbsp;·&nbsp; ${t('dueLabel')}: ${site.due}<br/>${t('statusLabel')}: <b>${statusValLabel(site.status)}</b></div>
  </div>`;
}

function openSite(id){
  S.activeSite = SITES.find(s=>s.id===id);
  go('siteDetail');
}

function startFlow(site){
  S.activeSite = site; S.evidence=[]; S.aiFinding=null; S.findings=[]; S.voiceNote=null; S.formAnswers={};
  S.gpsVerified=null; S.gpsStatus='idle'; S.gpsMessage=''; S.userLatLng=null; S.gpsDistanceM=null; S.gpsTimestampMs=null;
  go('siteDetail');
}

function screenInspectionList(){
  return `<div class="screen-body">
    ${header(t('inspectionsTitle'),'8 '+t('assignedThisWeek'))}
    <div class="content">
      <div class="field"><input type="text" placeholder="${t('searchInspections')}" /></div>
      <div class="filter-bar">
        <span class="filter-pill active">${t('filterAll')}</span>
        <span class="filter-pill">${t('filterPending')}</span>
        <span class="filter-pill">${t('filterInProgress')}</span>
        <span class="filter-pill">${t('filterSubmitted')}</span>
        <span class="filter-pill">${t('filterPriority')}</span>
      </div>
      ${SITES.map(s=>`
        <div class="task-card" onclick='openSite(${JSON.stringify(s.id)})'>
          <div class="task-top">
            <div class="task-title">${s.name}</div>
            <span class="badge ${statusBadge(s.status)}">${statusValLabel(s.status)}</span>
          </div>
          <div class="task-meta">${s.id} · ${s.type}<br/>📍 ${s.location} · ${t('priorityColon')}: <b>${priorityLabel(s.priority)}</b></div>
        </div>`).join('')}
    </div>
  </div>`;
}

function statusBadge(s){
  return {Pending:'warning','In Progress':'info',Submitted:'info',Reviewed:'success',Closed:'success'}[s] || 'neutral';
}

function screenSiteDetail(){
  const s = S.activeSite;
  return `<div class="screen-body">
    ${header(t('siteInformation'), s.id, "setNavTab('home')")}
    <div class="content">
      <div class="card">
        <h3 style="font-size:16px;">${s.name}</h3>
        <div class="divider"></div>
        <div class="check-row"><span style="color:var(--muted);">${t('siteId')}</span><span style="margin-left:auto;font-weight:700;">${s.id}</span></div>
        <div class="check-row"><span style="color:var(--muted);">${t('location')}</span><span style="margin-left:auto;font-weight:700;">${s.location}</span></div>
        <div class="check-row"><span style="color:var(--muted);">${t('inspectionType')}</span><span style="margin-left:auto;font-weight:700;">${s.type}</span></div>
        <div class="check-row"><span style="color:var(--muted);">${t('priority')}</span><span style="margin-left:auto;"><span class="badge ${badgeClass(s.priority)}">${priorityLabel(s.priority).toUpperCase()}</span></span></div>
        <div class="check-row"><span style="color:var(--muted);">${t('dueDate')}</span><span style="margin-left:auto;font-weight:700;">${s.due==='Today'?'03 September 2026':s.due}</span></div>
        <div class="check-row"><span style="color:var(--muted);">${t('lastInspection')}</span><span style="margin-left:auto;font-weight:700;">${s.last}</span></div>
        <div class="check-row"><span style="color:var(--muted);">${t('previousIssues')}</span><span style="margin-left:auto;font-weight:700;">${s.prevIssues}</span></div>
      </div>

      <div class="section-label">${t('siteIdentification')}</div>
      <button class="btn btn-outline" onclick="openQrModal()">${t('scanSiteQr')}</button>
      ${S.qrScanned ? `<div class="banner ok" style="margin-top:10px;">✅ ${s.id} ${t('identified')} ${s.name}${S.qrPayload ? `<div style="font-size:11px; opacity:.8; margin-top:4px; word-break:break-all;">${t('qrScannedData')} ${escHtml(S.qrPayload)}</div>` : ''}</div>` : ''}
    </div>
    <div class="fab-start">
      <div class="btn-row">
        <button class="btn btn-ghost" style="border:1.5px solid var(--border);" onclick="go('reinspect')">${t('viewPrevious')}</button>
        <button class="btn btn-accent" onclick="go('gps')">${t('startInspection')}</button>
      </div>
    </div>
    ${S.qrModal ? qrModal() : ''}
  </div>`;
}

function screenIssues(){
  return `<div class="screen-body">
    ${header(t('issueTracking'),`2 ${t('critical').toLowerCase()} · 5 total`)}
    <div class="content">
      <div class="filter-bar">
        <span class="filter-pill active">${t('filterAll')}</span>
        <span class="filter-pill">${t('critical')}</span>
        <span class="filter-pill">${t('filterInProgress')}</span>
        <span class="filter-pill">${t('resolved')}</span>
      </div>
      ${ISSUES.map(i=>`
        <div class="task-card" onclick="go('reinspect')">
          <div class="task-top">
            <div class="task-title">${i.title}</div>
            <span class="badge ${badgeClass(i.severity)}">${sevIcon(i.severity)} ${severityLabel(i.severity)}</span>
          </div>
          <div class="task-meta">${i.site} · ${t('assignedColon')}: ${i.assignee}<br/>${t('statusLabel')}: <b>${i.status}</b> · ${t('dueShort')} ${i.due}</div>
        </div>`).join('')}
    </div>
  </div>`;
}

function sevIcon(s){ return {Critical:'🔴',High:'🟠',Medium:'🟡',Low:'🟢'}[s]||''; }

function screenNotifications(){
  const items = [
    {icon:'🔴', text:t('n_critical'), time:t('t_2min')},
    {icon:'📋', text:t('n_new'), time:t('t_1hr')},
    {icon:'⚠️', text:t('n_due'), time:t('t_3hr')},
    {icon:'🔄', text:t('n_reinspect'), time:t('t_yesterday')},
    {icon:'✅', text:t('n_resolved'), time:t('t_2days')},
  ];
  return `<div class="screen-body">
    ${header(t('notifications'), items.length+' '+t('updates'))}
    <div class="content">
      ${items.map(n=>`
        <div class="task-card" style="cursor:default;">
          <div style="display:flex; gap:10px; align-items:flex-start;">
            <span style="font-size:17px;">${n.icon}</span>
            <div style="flex:1;"><div style="font-size:13px; font-weight:600;">${n.text}</div>
            <div style="font-size:11.5px; color:var(--muted); margin-top:3px;">${n.time}</div></div>
          </div>
        </div>`).join('')}
    </div>
  </div>`;
}
