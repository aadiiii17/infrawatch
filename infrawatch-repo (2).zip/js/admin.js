/* admin.js
 * Admin Command Center: login, dashboard, live map screen, inspectors, issues, analytics and reports.
 */

function renderAdmin(){
  const statusbar = `<div class="statusbar"><span class="statusbar-clock">--:--</span><span>●●● 5G  <span class="statusbar-battery">🔋</span></span></div>`;

  if(!S.adminLoggedIn){
    return statusbar + adminLoginScreen();
  }

  let main = '';
  switch(S.adminScreen){
    case 'dashboard': main = adminDashboard(); break;
    case 'map': main = adminMap(); break;
    case 'inspectors': main = adminInspectors(); break;
    case 'issuesAdmin': main = adminIssues(); break;
    case 'analytics': main = adminAnalytics(); break;
    case 'reports': main = adminReport(); break;
    default: main = adminDashboard();
  }
  return statusbar + `
    <div class="app-header" style="justify-content:space-between;">
      <div class="brand" style="gap:8px;">
        <div class="brand-mark" style="width:30px;height:30px;font-size:12px;border-radius:8px;">IW</div>
        <div><div class="brand-name" style="font-size:13.5px;">Command Center</div><div class="brand-sub" style="font-size:10.5px;">Priya Menon · Admin</div></div>
      </div>
      <span class="chip" style="padding:6px 10px; cursor:pointer;" onclick="adminLogout()">⎋ ${t('logout')}</span>
    </div>
    <div class="screen-body admin-mobile"><div class="admin-main">${main}</div></div>
    ${adminBottomNav()}
  `;
}

function setAdminScreen(id){ S.adminScreen = id; render(); document.getElementById('admin-phone-screen').scrollTop=0; }

function adminBottomNav(){
  const items = [
    {id:'dashboard', icon:'📊', label:'Home'},
    {id:'map', icon:'🗺️', label:'Map'},
    {id:'inspectors', icon:'🧑\u200d🔧', label:'Team'},
    {id:'issuesAdmin', icon:'🛠️', label:'Issues'},
    {id:'analytics', icon:'📈', label:'Stats'},
    {id:'reports', icon:'📄', label:'Reports'},
  ];
  return `<div class="bottomnav admin-bottomnav">${items.map(i=>`
    <button class="nav-item ${S.adminScreen===i.id?'active':''}" onclick="setAdminScreen('${i.id}')">
      <span class="nav-icon">${i.icon}</span>${i.label}
    </button>`).join('')}</div>`;
}

function adminLoginScreen(){
  if(S.loginRole!=='admin') return rolePicker();
  return `<div class="screen-body">
    <div class="content" style="padding-top:50px;">
      <div style="text-align:center; margin-bottom:28px;">
        <div style="width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,var(--primary-dark),var(--primary));box-shadow:0 10px 22px -8px rgba(37,99,235,.6);
          display:flex;align-items:center;justify-content:center;margin:0 auto 12px;">
          <span style="font-size:24px;">🛰️</span>
        </div>
        <h2 style="font-size:18px;">Command Center</h2>
        <div class="sub" style="color:var(--muted); font-size:12.5px; margin-top:2px;">${t('admin')} · ${t('signInContinue')}</div>
        <div style="color:var(--primary); font-size:12px; font-weight:700; cursor:pointer; margin-top:8px;" onclick="changeRole()">← ${t('changeRole')}</div>
      </div>
      <div class="field"><label>${t('emailUserId')}</label><input id="adminLoginEmail" type="text" placeholder="demo.admin@example.com" /></div>
      <div class="field"><label>${t('password')}</label><input id="adminLoginPassword" type="password" placeholder="••••••••" /></div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:18px; font-size:12.5px;">
        <label style="display:flex; align-items:center; gap:6px; color:var(--muted);"><input type="checkbox" style="width:auto;"/> ${t('rememberMe')}</label>
        <span style="color:var(--primary); font-weight:600; cursor:pointer;">${t('forgotPassword')}</span>
      </div>
      <button class="btn btn-primary" onclick="adminLoginSubmit()">${t('logIn')}</button>
      <div class="divider"></div>
      <div class="section-label" style="margin:0 0 8px;">${t('demoAccounts')}</div>
      <div class="card" style="display:flex; justify-content:space-between; align-items:center; padding:11px 14px;">
        <div><div style="font-weight:700; font-size:13px;">${t('admin')}</div><div style="font-size:11.5px; color:var(--muted);">demo.admin@example.com</div></div>
        <button class="btn btn-outline btn-sm" onclick="adminLoginQuickUse()">${t('use')}</button>
      </div>
    </div>
  </div>`;
}

function adminLoginSubmit(){
  const email = (document.getElementById('adminLoginEmail').value||'').trim();
  const pw = (document.getElementById('adminLoginPassword').value||'').trim();
  if(!email || !pw){ showToast(t('enterCredentials')); return; }
  S.adminLoggedIn = true; S.adminScreen = 'dashboard'; render();
}

function adminLoginQuickUse(){ S.adminLoggedIn = true; S.adminScreen = 'dashboard'; render(); }

function adminLogout(){ S.adminLoggedIn = false; S.loginRole = null; render(); }

function adminLoginUseInspector(){
  setAppMode('inspector');
  loginAs('inspector');
}

function adminDashboard(){
  return `
  <div class="admin-header">
    <div><div class="admin-title">INFRAWATCH COMMAND CENTER</div><div class="admin-sub">Live overview across all active sites · Updated just now</div></div>
    <div class="filter-bar" style="margin:0;">
      <span class="filter-pill active">Today</span><span class="filter-pill">7 Days</span><span class="filter-pill">30 Days</span>
    </div>
  </div>
  <div class="kpi-grid">
    <div class="kpi"><div class="n">1,248</div><div class="l">Total Inspections</div></div>
    <div class="kpi"><div class="n" style="color:var(--success);">932</div><div class="l">Completed</div></div>
    <div class="kpi"><div class="n" style="color:var(--warning);">216</div><div class="l">Pending</div></div>
    <div class="kpi"><div class="n" style="color:var(--critical);">100</div><div class="l">Critical Issues</div></div>
    <div class="kpi"><div class="n">48</div><div class="l">Active Inspectors</div></div>
  </div>
  <div class="grid-2">
    <div>
      <div style="font-weight:700; margin-bottom:10px;">Live Monitoring Map</div>
      ${mapMarkersHTML(220, 'admin-map-dashboard')}
    </div>
    <div>
      <div style="font-weight:700; margin-bottom:10px;">Field Activity</div>
      <div class="card" style="padding:0;">
        ${INSPECTORS.map(i=>`<div class="check-row" style="padding:12px 16px;">
          <div>
            <div style="font-weight:700; font-size:12.5px;">${i.name}</div>
            <div style="font-size:11.5px; color:var(--muted);">${i.site}</div>
          </div>
          <span style="margin-left:auto;"><span class="badge ${i.status==='Inspecting'?'info':i.status==='Completed'?'success':'warning'}">${i.status}</span></span>
        </div>`).join('')}
      </div>
    </div>
  </div>
  <div class="grid-2" style="margin-top:18px;">
    <div class="card">
      <div style="font-weight:700; margin-bottom:6px;">Inspections per Day</div>
      ${barChart([40,52,48,61,58,70,66], ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'])}
    </div>
    <div class="card">
      <div style="font-weight:700; margin-bottom:10px;">Predictive Maintenance — Site Risk</div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span style="font-size:13px; font-weight:600;">Site 17</span><span style="font-weight:800; color:var(--critical);">82 / 100 · HIGH RISK</span>
      </div>
      <div class="confidence-bar" style="height:8px;"><div class="confidence-fill" style="width:82%; background:var(--critical);"></div></div>
      <div style="font-size:11.5px; color:var(--muted); margin-top:10px;">Factors: previous defects · recent findings · defect severity · inspection history</div>
    </div>
  </div>`;
}

function adminMap(){
  return `
  <div class="admin-header"><div><div class="admin-title">Live Monitoring Map</div><div class="admin-sub">Tap a marker to view site details</div></div></div>
  ${mapMarkersHTML(400, 'admin-map-full')}`;
}

function adminInspectors(){
  return `
  <div class="admin-header"><div><div class="admin-title">Live Inspector Monitoring</div><div class="admin-sub">48 active inspectors across 5 regions</div></div></div>
  <div class="card" style="padding:0;">
    <table>
      <thead><tr><th>Inspector</th><th>Site</th><th>Status</th><th>Last Update</th></tr></thead>
      <tbody>
        ${INSPECTORS.map(i=>`<tr><td style="font-weight:700;">${i.name}</td><td>${i.site}</td>
          <td><span class="badge ${i.status==='Inspecting'?'info':i.status==='Completed'?'success':'warning'}">${i.status}</span></td>
          <td style="color:var(--muted);">${i.update}</td></tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

function adminIssues(){
  return `
  <div class="admin-header"><div><div class="admin-title">Issue Tracking Dashboard</div><div class="admin-sub">5 issues · 1 critical · 1 overdue</div></div></div>
  <div class="filter-bar">
    ${['All','Open','Assigned','In Progress','Resolved','Overdue','Critical'].map(f=>`<span class="filter-pill ${S.issueFilter===f?'active':''}" onclick="setIssueFilter('${f}')">${f}</span>`).join('')}
  </div>
  <div class="card" style="padding:0;">
    <table>
      <thead><tr><th>Issue</th><th>Site</th><th>Severity</th><th>Status</th><th>Assigned To</th><th>Due</th></tr></thead>
      <tbody>
        ${ISSUES.map(i=>`<tr><td style="font-weight:700;">${i.title}<div style="color:var(--muted); font-weight:400; font-size:11px;">${i.id}</div></td>
          <td>${i.site}</td><td><span class="badge ${badgeClass(i.severity)}">${i.severity}</span></td>
          <td>${i.status}</td><td>${i.assignee==='Unassigned'?`<button class="btn btn-outline btn-sm" onclick="assignIssue('${i.id}')">Assign</button>`:i.assignee}</td>
          <td style="color:var(--muted);">${i.due}</td></tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

function setIssueFilter(f){ S.issueFilter = f; render(); }

function assignIssue(id){ showToastAdmin('Issue '+id+' assigned to Engineer D'); }

function barChart(vals, labels){
  const max = Math.max(...vals);
  return `<div class="bar-chart">
    ${vals.map((v,i)=>`<div class="col"><div class="bar" style="height:${(v/max*120)}px;" title="${v}"></div><div class="lab">${labels[i]}</div></div>`).join('')}
  </div>`;
}

function adminAnalytics(){
  return `
  <div class="admin-header">
    <div><div class="admin-title">Analytics</div><div class="admin-sub">Trends across inspections, defects and resolution</div></div>
    <div class="filter-bar" style="margin:0;">
      ${['Today','7 Days','30 Days','Custom'].map(f=>`<span class="filter-pill ${S.analyticsRange===f?'active':''}" onclick="setRange('${f}')">${f}</span>`).join('')}
    </div>
  </div>
  <div class="grid-2">
    <div class="card"><div style="font-weight:700; margin-bottom:6px;">Monthly Inspection Trend</div>${barChart([210,240,265,300,280,320,310,340,360,355,380,410],['J','F','M','A','M','J','J','A','S','O','N','D'])}</div>
    <div class="card"><div style="font-weight:700; margin-bottom:10px;">Defects by Category</div>
      ${['Surface Crack','Corrosion','Surface Damage','Leakage','Missing Component'].map((d,i)=>{
        const pct=[38,26,18,12,6][i];
        return `<div style="margin-bottom:9px;"><div style="display:flex; justify-content:space-between; font-size:12px;"><span>${d}</span><span class="num">${pct}%</span></div><div class="confidence-bar"><div class="confidence-fill" style="width:${pct}%; background:var(--primary-2);"></div></div></div>`;
      }).join('')}
    </div>
  </div>
  <div class="grid-2" style="margin-top:18px;">
    <div class="card"><div style="font-weight:700; margin-bottom:6px;">Resolution Time (avg days)</div>${barChart([5.2,4.6,3.9,3.1],['Critical','High','Medium','Low'])}</div>
    <div class="card"><div style="font-weight:700; margin-bottom:6px;">Inspector Workload</div>${barChart([14,11,9,7],['Rahul','Amit','Neha','Suresh'])}</div>
  </div>`;
}

function setRange(r){ S.analyticsRange = r; render(); }

function adminReport(){
  return `
  <div class="admin-header"><div><div class="admin-title">Report Generation</div><div class="admin-sub">Preview and export inspection reports</div></div></div>
  <div class="grid-2">
    <div class="card">
      <div style="text-align:center; padding:10px 0 18px; border-bottom:1px solid var(--border); margin-bottom:14px;">
        <div style="font-weight:800; letter-spacing:.5px; font-size:13px; color:var(--muted);">INFRAWATCH REPORT</div>
        <div style="font-size:19px; font-weight:800; margin-top:6px;">Bridge – Site 17 · SITE-017</div>
      </div>
      ${reportRow('Inspector','Rahul Sharma · EMP-2291')}
      ${reportRow('Date / Time','03 September 2026 · 10:32 AM')}
      ${reportRow('GPS Coordinates','28.6139° N, 77.2090° E')}
      ${reportRow('Checklist','10 / 10 sections completed')}
      ${reportRow('AI Findings','Surface Crack — 91% confidence')}
      ${reportRow('Severity','HIGH')}
      ${reportRow('Photos','6 · Video: 1 · Voice note: 1')}
      ${reportRow('Recommendation','Schedule detailed technical inspection')}
      ${reportRow('Issue Status','Assigned — Engineer A')}
      ${reportRow('Integrity Score','96%')}
      <div class="btn-row" style="margin-top:16px;">
        <button class="btn btn-outline" onclick="downloadAdminReportPdf()">GENERATE PDF</button>
        <button class="btn btn-primary" onclick="downloadAdminReportPdf()">DOWNLOAD REPORT</button>
      </div>
    </div>
    <div>
      <div class="card" style="margin-bottom:14px;">
        <div style="font-weight:700; margin-bottom:8px;">Report Queue</div>
        ${SITES.map(s=>`<div class="check-row"><span>${s.name}</span><span style="margin-left:auto; color:var(--muted); font-size:11.5px;">${s.status}</span></div>`).join('')}
      </div>
    </div>
  </div>`;
}

function downloadAdminReportPdf(){
  const rows = [
    ['Site', 'Bridge – Site 17 · SITE-017'],
    ['Inspector', 'Rahul Sharma · EMP-2291'],
    ['Date / Time', '03 September 2026 · 10:32 AM'],
    ['GPS Coordinates', '28.6139° N, 77.2090° E'],
    ['Checklist', '10 / 10 sections completed'],
    ['AI Findings', 'Surface Crack — 91% confidence'],
    ['Severity', 'HIGH'],
    ['Photos', '6 · Video: 1 · Voice note: 1'],
    ['Recommendation', 'Schedule detailed technical inspection'],
    ['Issue Status', 'Assigned — Engineer A'],
    ['Integrity Score', '96%'],
  ];
  buildAndDownloadPdf('INFRAWATCH REPORT', 'SITE-017', rows, 'Inspection_Report_SITE-017.pdf');
  showToastAdmin('Report downloaded');
}
