/* main.js
 * Entry point. Loaded last: restores saved profile settings, shows the first screen and starts the status bar.
 */

loadProfile();
setAppMode('inspector');
render();
initStatusBar();
