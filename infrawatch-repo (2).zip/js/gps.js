/* gps.js
 * GPS verification: real device location, distance to the site (Haversine) and the GPS screen.
 */

function screenGPS(){
  const site = S.activeSite;
  const status = S.gpsStatus;
  const locating = status==='idle' || status==='locating';
  const hasFix = status==='ok';
  const verified = hasFix && S.gpsVerified===true;

  let distanceText = '—';
  if(hasFix && S.gpsDistanceM!=null){
    distanceText = S.gpsDistanceM < 1000 ? `${Math.round(S.gpsDistanceM)} meters` : `${(S.gpsDistanceM/1000).toFixed(2)} km`;
  }
  let timestampText = '—';
  if(hasFix && S.gpsTimestampMs){
    timestampText = new Date(S.gpsTimestampMs).toLocaleTimeString('en-IN', { hour:'numeric', minute:'2-digit' });
  }

  let statusBadge;
  if(locating){ statusBadge = `<span class="badge neutral">${t('locatingSite')}</span>`; }
  else if(verified){ statusBadge = `<span class="badge success">${t('locationVerified')}</span>`; }
  else if(hasFix){ statusBadge = `<span class="badge critical">${t('locationNotVerified')}</span>`; }
  else { statusBadge = `<span class="badge critical">${t('locationNotVerified')}</span>`; }

  const showRetry = status==='denied' || status==='unsupported' || status==='iframe' || status==='insecure' || status==='timeout' || status==='error' || (hasFix && !verified);

  return `<div class="screen-body">
    ${header(t('gpsVerification'), site.id, "go('siteDetail')")}
    <div class="content">
      <div class="gps-map-wrap">
        <div class="map-loading" id="gps-map-loading">${t('locatingSite')}</div>
        <div id="gps-leaflet-map" style="width:100%; height:100%;"></div>
        <div class="recenter-btn" onclick="if(window.gpsMapInstance) window.gpsMapInstance.fitBounds(window.gpsMapBounds, {padding:[36,36], maxZoom:16})">${t('recenter')}</div>
      </div>
      <div class="card" style="margin-top:14px;">
        <div class="check-row"><span>${t('distanceToSite')}</span><span style="margin-left:auto; font-weight:800;" id="gps-distance">${distanceText}</span></div>
        <div class="check-row"><span>${t('timestamp')}</span><span style="margin-left:auto; font-weight:700;">${timestampText}</span></div>
        <div class="check-row" style="border-bottom:none;"><span>${t('statusLabel')}</span><span style="margin-left:auto;" id="gps-status">${statusBadge}</span></div>
      </div>
      ${!locating && S.gpsMessage ? `<div class="banner ${hasFix && !verified ? 'warn' : 'warn'}">${escHtml(S.gpsMessage)}</div>` : ''}
      ${showRetry ? `<button class="btn btn-outline" onclick="requestGpsLocation()">📍 ${t('retryGps')}</button>` : ''}
    </div>
    <div class="fab-start">
      <button class="btn btn-accent" ${verified?'':'disabled style="opacity:.5;"'} onclick="go('form')">${t('startInspection')}</button>
    </div>
  </div>`;
}

/* Real device location, checked against the assigned site's real coordinates */
function requestGpsLocation(){
  S.gpsStatus = 'locating'; S.gpsMessage=''; render();

  if(window.self !== window.top){
    S.gpsStatus='iframe'; S.gpsMessage='This preview is running inside an embedded frame, which blocks location access for security. Download the file and open it directly in a browser tab, then retry.';
    render(); return;
  }
  if(!navigator.geolocation){
    S.gpsStatus='unsupported'; S.gpsMessage='Location isn\'t supported in this browser.';
    render(); return;
  }
  if(!window.isSecureContext){
    S.gpsStatus='insecure'; S.gpsMessage='Location access needs a secure context (HTTPS or a local file).';
    render(); return;
  }

  navigator.geolocation.getCurrentPosition(
    pos=>{
      const site = S.activeSite;
      const lat = pos.coords.latitude, lng = pos.coords.longitude;
      const dist = haversineMeters(lat, lng, site.lat, site.lng);
      S.userLatLng = [lat, lng];
      S.gpsDistanceM = dist;
      S.gpsTimestampMs = Date.now();
      S.gpsStatus = 'ok';
      S.gpsVerified = dist <= GPS_VERIFY_RADIUS_M;
      S.gpsMessage = S.gpsVerified ? '' : `You're ${Math.round(dist)}m away — move within ${GPS_VERIFY_RADIUS_M}m of the site to verify.`;
      render();
      setTimeout(initGpsMap, 0);
    },
    err=>{
      if(err && err.code===err.PERMISSION_DENIED){
        S.gpsStatus='denied'; S.gpsMessage='Location access is blocked for this page. Allow it via the browser\'s address-bar icon or Settings → Site permissions, then retry.';
      } else if(err && err.code===err.TIMEOUT){
        S.gpsStatus='timeout'; S.gpsMessage='Location request timed out — check your GPS signal and retry.';
      } else {
        S.gpsStatus='error'; S.gpsMessage='Couldn\'t get your location right now — retry when you have a GPS signal.';
      }
      render();
    },
    { enableHighAccuracy:true, timeout:12000, maximumAge:0 }
  );
}

function haversineMeters(lat1, lng1, lat2, lng2){
  const R = 6371000;
  const toRad = d => d * Math.PI / 180;
  const dLat = toRad(lat2 - lat1), dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}
