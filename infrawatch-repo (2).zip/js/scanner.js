/* scanner.js
 * Site QR scanner: live camera decoding with jsQR, or decoding an uploaded / photographed QR image.
 */

function openQrModal(){
  S.qrModal = true; render();
  setTimeout(initQrScanner, 0);
}

function closeQrModal(){
  stopQrScanner();
  S.qrModal = false; render();
}

function setQrStatus(text){
  const statusEl = document.getElementById('qr-status');
  const msgEl = document.getElementById('qr-status-msg');
  const videoEl = document.getElementById('qr-feed');
  if(videoEl) videoEl.style.display = 'none';
  if(statusEl) statusEl.style.display = 'flex';
  if(msgEl) msgEl.textContent = text;
}

function initQrScanner(){
  const videoEl = document.getElementById('qr-feed');
  if(!videoEl) return; // modal already closed

  if(typeof jsQR !== 'function'){
    setQrStatus(t('qrLibError'));
    return;
  }
  if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.isSecureContext){
    setQrStatus('Live camera scanning isn\'t available here. Use "Upload / take photo of QR" below instead.');
    return;
  }

  setQrStatus(t('startingCamera'));
  navigator.mediaDevices.getUserMedia({ video:{ facingMode:{ ideal:'environment' } }, audio:false })
    .then(stream=>{
      window.qrStream = stream;
      const el = document.getElementById('qr-feed');
      if(!el){ stream.getTracks().forEach(tr=>tr.stop()); return; } // navigated away mid-request
      el.srcObject = stream;
      el.style.display = 'block';
      el.play().catch(()=>{});
      const statusEl = document.getElementById('qr-status');
      if(statusEl) statusEl.style.display = 'none';
      window.qrScanCanvas = document.createElement('canvas');
      scanQrFrame();
    })
    .catch(err=>{
      let msg;
      if(err && err.name==='NotAllowedError'){
        msg = 'Live camera is blocked here (allow it in your browser, or this embedded preview may not permit it). You can still scan by tapping "Upload / take photo of QR" below.';
      } else if(err && err.name==='NotFoundError'){
        msg = 'No camera was found on this device. You can upload a QR image below instead.';
      } else {
        msg = 'Live camera unavailable right now. You can upload / take a photo of the QR below instead.';
      }
      setQrStatus(msg);
    });
}

function handleQrFile(input){
  const file = input.files && input.files[0];
  input.value = '';
  if(!file) return;
  if(typeof jsQR !== 'function'){ showToast(t('qrLibError')); return; }
  const img = new Image();
  const url = URL.createObjectURL(file);
  img.onload = ()=>{
    const scale = Math.min(1, 1200 / Math.max(img.width, img.height));
    const c = document.createElement('canvas');
    c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
    const ctx = c.getContext('2d');
    ctx.drawImage(img, 0, 0, c.width, c.height);
    URL.revokeObjectURL(url);
    const data = ctx.getImageData(0, 0, c.width, c.height);
    const code = jsQR(data.data, data.width, data.height, { inversionAttempts:'attemptBoth' });
    if(code && code.data){ onQrDetected(code.data); }
    else { showToast(t('qrNotFound')); }
  };
  img.onerror = ()=>{ URL.revokeObjectURL(url); showToast(t('qrNotFound')); };
  img.src = url;
}

function scanQrFrame(){
  const video = document.getElementById('qr-feed');
  if(!video || !S.qrModal) return; // modal closed / navigated away — stop the loop
  if(video.readyState === video.HAVE_ENOUGH_DATA && video.videoWidth){
    const canvas = window.qrScanCanvas;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    try{
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height);
      if(code && code.data){
        onQrDetected(code.data);
        return;
      }
    }catch(e){ /* frame not readable this tick — keep scanning */ }
  }
  window.qrRAF = requestAnimationFrame(scanQrFrame);
}

function onQrDetected(payload){
  stopQrScanner();
  S.qrModal = false;
  S.qrScanned = true;
  S.qrPayload = payload;
  render();
  showToast(t('qrScanned'));
}

function stopQrScanner(){
  if(window.qrRAF){ cancelAnimationFrame(window.qrRAF); window.qrRAF = null; }
  if(window.qrStream){ window.qrStream.getTracks().forEach(tr=>tr.stop()); window.qrStream = null; }
}

function qrModal(){
  return `<div class="modal-overlay" onclick="if(event.target===this) closeQrModal()">
    <div class="modal-sheet">
      <div class="sheet-handle"></div>
      <h3 style="font-size:16px; margin-bottom:14px;">${t('scanSiteQr')}</h3>
      <div class="camera-preview" style="height:260px;">
        <video id="qr-feed" autoplay playsinline muted style="display:none;"></video>
        <div class="camera-overlay-text" id="qr-status">
          <div id="qr-status-msg">${t('startingCamera')}</div>
          <button class="camera-retry-btn" onclick="initQrScanner()">${t('retryCameraAccess')}</button>
        </div>
        <div class="camera-frame-corner cc-tl"></div><div class="camera-frame-corner cc-tr"></div>
        <div class="camera-frame-corner cc-bl"></div><div class="camera-frame-corner cc-br"></div>
      </div>
      <div style="font-size:12px; color:var(--muted); text-align:center; margin-top:10px;">${t('pointCameraQr')}</div>
      <input type="file" id="qr-file" accept="image/*" capture="environment" style="display:none;" onchange="handleQrFile(this)" />
      <button class="btn btn-primary" style="margin-top:14px;" onclick="document.getElementById('qr-file').click()">${t('uploadQr')}</button>
      <div class="btn-row" style="margin-top:10px;">
        <button class="btn btn-outline" onclick="closeQrModal()">${t('cancel')}</button>
      </div>
    </div>
  </div>`;
}
