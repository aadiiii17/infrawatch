/* auth.js
 * Splash screen, role picker and the Inspector login flow.
 */

function screenSplash(){
  setTimeout(()=>{ if(S.screen==='splash'){ go('login'); } }, 1400);
  return `<div class="screen-body" style="align-items:center; justify-content:center; display:flex;">
    <div style="text-align:center;">
      <div style="width:74px;height:74px;border-radius:20px;background:linear-gradient(135deg,var(--primary-dark),var(--primary));box-shadow:0 10px 22px -8px rgba(37,99,235,.6);
        display:flex;align-items:center;justify-content:center;margin:0 auto 18px;">
        <span style="font-size:32px;">🛰️</span>
      </div>
      <div style="font-family:'Plus Jakarta Sans';font-weight:800;font-size:21px;letter-spacing:.5px;">INFRAWATCH</div>
      <div style="font-size:12.5px;color:var(--muted);margin-top:6px;">${t('tagline')}</div>
    </div>
  </div>`;
}

function screenLogin(){
  if(S.loginRole!=='inspector') return rolePicker();
  return `<div class="screen-body">
    <div class="content" style="padding-top:50px;">
      <div style="text-align:center; margin-bottom:28px;">
        <div style="width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,var(--primary-dark),var(--primary));box-shadow:0 10px 22px -8px rgba(37,99,235,.6);
          display:flex;align-items:center;justify-content:center;margin:0 auto 12px;">
          <span style="font-size:24px;">🛰️</span>
        </div>
        <h2 style="font-size:18px;">InfraWatch</h2>
        <div class="sub" style="color:var(--muted); font-size:12.5px; margin-top:2px;">${t('inspector')} · ${t('signInContinue')}</div>
        <div style="color:var(--primary); font-size:12px; font-weight:700; cursor:pointer; margin-top:8px;" onclick="changeRole()">← ${t('changeRole')}</div>
      </div>
      <div class="field"><label>${t('emailUserId')}</label><input id="loginEmail" type="text" placeholder="demo.inspector@example.com" /></div>
      <div class="field"><label>${t('password')}</label><input id="loginPassword" type="password" placeholder="••••••••" /></div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:18px; font-size:12.5px;">
        <label style="display:flex; align-items:center; gap:6px; color:var(--muted);"><input type="checkbox" style="width:auto;"/> ${t('rememberMe')}</label>
        <span style="color:var(--primary); font-weight:600; cursor:pointer;">${t('forgotPassword')}</span>
      </div>
      <button class="btn btn-primary" onclick="loginSubmit()">${t('logIn')}</button>
      <div class="divider"></div>
      <div class="section-label" style="margin:0 0 8px;">${t('demoAccounts')}</div>
      <div class="card" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; padding:11px 14px;">
        <div><div style="font-weight:700; font-size:13px;">${t('inspector')}</div><div style="font-size:11.5px; color:var(--muted);">demo.inspector@example.com</div></div>
        <button class="btn btn-outline btn-sm" onclick="loginAs('inspector')">${t('use')}</button>
      </div>
    </div>
  </div>`;
}

function rolePicker(){
  const card=(id,icon,title,desc)=>`
    <div class="card" style="display:flex; align-items:center; gap:14px; padding:16px; margin-bottom:12px; cursor:pointer;" onclick="pickRole('${id}')">
      <div style="width:46px;height:46px;border-radius:14px;background:var(--primary-tint);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;">${icon}</div>
      <div style="flex:1;"><div style="font-weight:800; font-size:14.5px; font-family:'Plus Jakarta Sans';">${title}</div><div style="font-size:11.5px; color:var(--muted); margin-top:2px;">${desc}</div></div>
      <span style="color:var(--primary); font-weight:800;">→</span>
    </div>`;
  return `<div class="screen-body"><div class="content" style="padding-top:50px;">
    <div style="text-align:center; margin-bottom:30px;">
      <div style="width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,var(--primary-dark),var(--primary));box-shadow:0 10px 22px -8px rgba(37,99,235,.6);display:flex;align-items:center;justify-content:center;margin:0 auto 12px;"><span style="font-size:24px;">🛰️</span></div>
      <h2 style="font-size:18px;">${t('verifyRole')}</h2>
      <div class="sub" style="color:var(--muted); font-size:12.5px; margin-top:2px;">${t('chooseRole')}</div>
    </div>
    ${card('inspector','🧑\u200d🔧',t('inspector'),t('inspectorDesc'))}
    ${card('admin','📊',t('admin'),t('adminDesc'))}
  </div></div>`;
}

function pickRole(role){ S.loginRole = role; setAppMode(role); }

function changeRole(){ S.loginRole = null; render(); }

function inspectorLogout(){ S.loginRole = null; go('login'); }

function loginAs(role){
  S.role = role; S.navTab='home';
  go('home');
}

function loginSubmit(){
  const email = (document.getElementById('loginEmail').value||'').trim();
  const pw = (document.getElementById('loginPassword').value||'').trim();
  if(!email || !pw){ showToast(t('enterCredentials')); return; }
  loginAs('inspector');
}

function loginAsAdmin(){
  S.loginRole='admin'; S.adminLoggedIn=true; S.adminScreen='dashboard';
  showToastQuick();
  setAppMode('admin');
}
