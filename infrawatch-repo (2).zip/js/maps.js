/* maps.js
 * Leaflet maps: shared base tiles, the GPS check-in map and the Admin live monitoring map.
 */

/* Leaflet map for GPS verification screen */
/* Base map tiles: Esri World Street Map (free, no key). Falls back to OpenStreetMap if Esri tiles keep failing. */
function addBaseTiles(map){
  const esri = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
    maxZoom:19, maxNativeZoom:16, attribution:'Tiles &copy; Esri'
  }).addTo(map);
  let errors = 0, switched = false;
  esri.on('tileerror', ()=>{
    errors++;
    if(errors >= 4 && !switched){
      switched = true;
      map.removeLayer(esri);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom:19, maxNativeZoom:18, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors'
      }).addTo(map);
    }
  });
}

function initGpsMap(attempt){
  attempt = attempt || 0;
  const el = document.getElementById('gps-leaflet-map');
  if(!el) return; // user navigated away before this fired
  if(typeof L === 'undefined'){
    // Leaflet library still loading from CDN — retry briefly, then fall back gracefully.
    if(attempt < 16){ setTimeout(()=>initGpsMap(attempt+1), 250); return; }
    renderGpsFallback(el);
    return;
  }
  if(window.gpsMapInstance){ window.gpsMapInstance.remove(); window.gpsMapInstance = null; }
  const site = S.activeSite;
  const siteLatLng = [site.lat, site.lng];
  const haveFix = S.gpsStatus==='ok' && S.userLatLng;
  const inspectorLatLng = haveFix ? S.userLatLng : null;

  const map = L.map(el, { zoomControl:true, attributionControl:false, scrollWheelZoom:false, maxZoom:18 }).setView(siteLatLng, 16);
  addBaseTiles(map);
  L.control.attribution({ position:'bottomleft', prefix:'' }).addTo(map);

  L.circle(siteLatLng, { radius:GPS_VERIFY_RADIUS_M, color:'#2563EB', weight:1.5, fillColor:'#2563EB', fillOpacity:0.08 }).addTo(map);

  const siteIcon = L.divIcon({ className:'', html:'<div style="width:16px;height:16px;border-radius:50%;background:#2563EB;border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.35);"></div>', iconSize:[16,16], iconAnchor:[8,8] });
  const meIcon = L.divIcon({ className:'', html:'<div style="width:16px;height:16px;border-radius:50%;background:#059669;border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.35);"></div>', iconSize:[16,16], iconAnchor:[8,8] });

  L.marker(siteLatLng, { icon:siteIcon }).addTo(map)
    .bindTooltip(t('assignedSiteLocation'), { permanent:true, direction:'top', offset:[0,-6], className:'pin-tooltip' });

  const boundsPoints = [siteLatLng];
  if(inspectorLatLng){
    L.marker(inspectorLatLng, { icon:meIcon }).addTo(map)
      .bindTooltip(t('youLabel'), { permanent:true, direction:'bottom', offset:[0,6], className:'pin-tooltip you' });
    L.polyline([siteLatLng, inspectorLatLng], { color:'#94A3B8', weight:2, dashArray:'4,6' }).addTo(map);
    boundsPoints.push(inspectorLatLng);
  }

  const bounds = L.latLngBounds(boundsPoints);
  window.gpsMapBounds = bounds.pad(0.6);
  map.fitBounds(window.gpsMapBounds, {maxZoom:16});
  window.gpsMapInstance = map;

  const loadingEl = document.getElementById('gps-map-loading');
  map.whenReady(()=>{ if(loadingEl) loadingEl.style.display='none'; });
  setTimeout(()=>{ map.invalidateSize(); }, 60);
}

/* Static fallback if the Leaflet library can't be reached (e.g. no network access) */
function renderGpsFallback(el){
  const loadingEl = document.getElementById('gps-map-loading');
  if(loadingEl) loadingEl.style.display = 'none';
  el.innerHTML = `
    <div style="position:relative; width:100%; height:100%;
      background:
        linear-gradient(0deg, rgba(15,23,42,.05) 1px, transparent 1px) 0 0/24px 24px,
        linear-gradient(90deg, rgba(15,23,42,.05) 1px, transparent 1px) 0 0/24px 24px,
        #E9EEF5;">
      <div style="position:absolute; width:34px; height:34px; border-radius:50%; background:rgba(5,150,105,.22);
        top:58%; left:40%; transform:translate(-50%,-50%);"></div>
      <div style="position:absolute; top:58%; left:40%; transform:translate(-50%,-100%); width:16px; height:16px;
        border-radius:50%; background:var(--success); border:3px solid #fff; box-shadow:0 2px 6px rgba(0,0,0,.3);"></div>
      <div style="position:absolute; top:42%; left:57%; transform:translate(-50%,-100%); width:16px; height:16px;
        border-radius:50%; background:var(--primary); border:3px solid #fff; box-shadow:0 2px 6px rgba(0,0,0,.3);"></div>
      <div style="position:absolute; bottom:10px; left:10px; font-size:10px; background:var(--surface); padding:4px 8px;
        border-radius:6px; color:var(--muted); font-weight:600;">${t('assignedSiteLocation')}</div>
      <div style="position:absolute; bottom:10px; right:10px; font-size:10px; background:var(--surface); padding:4px 8px;
        border-radius:6px; color:var(--success); font-weight:600;">${t('youLabel')}</div>
    </div>`;
}

function siteMapColor(status){
  return status==='Pending' ? '#D97706'
       : status==='In Progress' ? '#0EA5E9'
       : status==='Closed' ? '#059669'
       : status==='Submitted' ? '#7C3AED'
       : '#64748B';
}

function mapMarkersHTML(height, elId){
  return `<div id="${elId}" class="admin-map" style="height:${height}px;">
    <div id="${elId}-loading" style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; color:var(--muted); font-size:12px;">Loading live map…</div>
  </div>
  <div class="legend-row">
    <span><span class="legend-dot" style="background:#0EA5E9;"></span>In Progress</span>
    <span><span class="legend-dot" style="background:#D97706;"></span>Pending</span>
    <span><span class="legend-dot" style="background:#7C3AED;"></span>Submitted</span>
    <span><span class="legend-dot" style="background:#059669;"></span>Closed</span>
  </div>`;
}

function initAdminMap(elId, attempt){
  attempt = attempt || 0;
  const el = document.getElementById(elId);
  if(!el) return; // navigated away before this fired
  if(typeof L === 'undefined'){
    if(attempt < 16){ setTimeout(()=>initAdminMap(elId, attempt+1), 250); return; }
    el.innerHTML = '<div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; color:var(--muted); font-size:12px; text-align:center; padding:20px;">Live map needs a network connection to load map tiles. Open the downloaded file in a browser tab to see it.</div>';
    return;
  }
  if(window.adminMapInstances && window.adminMapInstances[elId]){ window.adminMapInstances[elId].remove(); }
  window.adminMapInstances = window.adminMapInstances || {};
  el.innerHTML = '';
  const map = L.map(el, { zoomControl:true, attributionControl:false }).setView([28.58,77.21], 10.2);
  addBaseTiles(map);
  L.control.attribution({ position:'bottomleft', prefix:'' }).addTo(map);

  const bounds = [];
  SITES.forEach(site=>{
    const color = siteMapColor(site.status);
    const icon = L.divIcon({ className:'', html:`<div style="width:16px;height:16px;border-radius:50%;background:${color};border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.35);"></div>`, iconSize:[16,16], iconAnchor:[8,8] });
    L.marker([site.lat, site.lng], { icon }).addTo(map)
      .bindPopup(`<div style="font-family:Inter,sans-serif;"><b>${site.id}</b> — ${site.name}<br/>Status: <b style="color:${color};">${site.status}</b><br/>Priority: ${site.priority} · Due: ${site.due}</div>`);
    bounds.push([site.lat, site.lng]);
  });
  map.fitBounds(L.latLngBounds(bounds).pad(0.35), {maxZoom:16});
  window.adminMapInstances[elId] = map;
  const loadingEl = document.getElementById(elId+'-loading');
  map.whenReady(()=>{ if(loadingEl) loadingEl.style.display='none'; });
  setTimeout(()=>{ map.invalidateSize(); }, 60);
}
