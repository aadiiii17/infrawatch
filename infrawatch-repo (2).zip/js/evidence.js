/* evidence.js
 * Evidence capture: live camera preview, photo capture/upload, voice notes and the capture screen.
 */

function initCameraPreview(){
  const videoEl = document.getElementById('camera-feed');
  if(!videoEl) return; // user already navigated away

  if(window.cameraStream){
    // Reuse the already-granted stream instead of prompting again / restarting capture.
    attachCameraStream(videoEl, window.cameraStream);
    return;
  }

  if(window.self !== window.top){
    // Embedded preview iframes block camera access by policy — this isn't a bug in the prototype,
    // opening the file directly in a browser tab resolves it.
    setCameraStatus('This preview is running inside an embedded frame, which blocks camera access for security. Download the file and open it directly in a browser tab, then retry.');
    return;
  }
  if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
    setCameraStatus('Camera preview isn\'t supported in this browser.');
    return;
  }
  if(!window.isSecureContext){
    setCameraStatus('Camera access needs a secure context (HTTPS or a local file) — showing evidence flow without a live feed.');
    return;
  }

  setCameraStatus('Starting camera…');
  navigator.mediaDevices.getUserMedia({ video:{ facingMode:'environment' }, audio:false })
    .then(stream=>{
      window.cameraStream = stream;
      const el = document.getElementById('camera-feed');
      if(!el){ stream.getTracks().forEach(t=>t.stop()); return; } // navigated away mid-request
      attachCameraStream(el, stream);
    })
    .catch(err=>{
      let msg;
      if(err && err.name==='NotAllowedError'){
        msg = 'Camera access is blocked for this page. Click the camera icon in your browser\'s address bar (or Settings → Site permissions) to allow it, then retry.';
      } else if(err && err.name==='NotFoundError'){
        msg = 'No camera was found on this device — showing evidence flow without a live feed.';
      } else {
        msg = 'Camera preview unavailable right now — showing evidence flow without a live feed.';
      }
      setCameraStatus(msg);
    });
}

function attachCameraStream(videoEl, stream){
  videoEl.srcObject = stream;
  videoEl.style.display = 'block';
  videoEl.play().catch(()=>{});
  const statusEl = document.getElementById('camera-status');
  if(statusEl) statusEl.style.display = 'none';
}

function setCameraStatus(text){
  const statusEl = document.getElementById('camera-status');
  const msgEl = document.getElementById('camera-status-msg');
  const videoEl = document.getElementById('camera-feed');
  if(videoEl) videoEl.style.display = 'none';
  if(statusEl) statusEl.style.display = 'flex';
  if(msgEl) msgEl.textContent = text;
}

function stopCameraPreview(){
  if(window.cameraStream){
    window.cameraStream.getTracks().forEach(t=>t.stop());
    window.cameraStream = null;
  }
}

function captureVideoFrame(){
  const video = document.getElementById('camera-feed');
  if(!video || !video.videoWidth) return null;
  try{
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.82);
  }catch(e){
    return null; // e.g. cross-origin/tainted canvas — fall back to placeholder thumbnail
  }
}

function screenCamera(){
  return `<div class="screen-body">
    ${header(t('evidenceCapture'), S.activeSite.id, "go('form')")}
    <div class="content">
      <div class="camera-preview">
        <video id="camera-feed" autoplay playsinline muted style="display:none;"></video>
        <div class="camera-overlay-text" id="camera-status">
          <div id="camera-status-msg">${t('startingCamera')}</div>
          <button class="camera-retry-btn" onclick="initCameraPreview()">${t('retryCameraAccess')}</button>
        </div>
        <div class="camera-frame-corner cc-tl"></div><div class="camera-frame-corner cc-tr"></div>
        <div class="camera-frame-corner cc-bl"></div><div class="camera-frame-corner cc-br"></div>
      </div>
      <div style="display:flex; justify-content:center; gap:22px; margin:18px 0 6px; align-items:center;">
        <button class="chip" onclick="captureEvidence('video')">${t('videoLabel')}</button>
        <div class="shutter" onclick="captureEvidence('photo')"></div>
        <button class="chip" onclick="triggerPhotoPicker()">${t('uploadLabel')}</button>
      </div>
      <input type="file" id="photo-upload-input" accept="image/*" capture="environment" style="display:none;" onchange="handlePhotoUpload(event)" />
      <div class="section-label">${t('capturedEvidence')} (${S.evidence.length})</div>
      <div class="evidence-grid">
        ${S.evidence.map(e=>`
          <div class="evidence-thumb" ${e.thumb?`style="background-image:url('${e.thumb}');background-size:cover;background-position:center;"`:''}>
            <div>
              <div class="tag">${e.id}</div>
              <div class="tag">✓ ${t('verified')} · ${e.time}</div>
            </div>
          </div>`).join('') || `<div style="font-size:12px;color:var(--muted); grid-column:1/-1;">${t('noEvidenceYet')}</div>`}
      </div>
      ${S.voiceNote ? voiceNoteCard() : `<button class="btn btn-outline" style="margin-top:16px;" onclick="openVoiceModal()">${t('addVoiceNote')}</button>`}
    </div>
    <div class="fab-start">
      <button class="btn btn-primary" ${S.evidence.length===0?'disabled style="opacity:.5;"':''} onclick="go('ai')">${t('runAiAnalysis')}</button>
    </div>
    ${S.voiceModal ? voiceModal() : ''}
  </div>`;
}

function captureEvidence(kind){
  if(kind==='photo'){
    const shot = captureVideoFrame();
    if(!shot){
      // No live camera frame available (permission blocked / no camera) — fall back
      // to letting the inspector actually pick/take a real photo instead of a blank card.
      triggerPhotoPicker();
      return;
    }
    addEvidenceItem('IMG', shot);
    showToast(t('evidenceCaptured'));
    return;
  }
  S.evidenceCount++;
  const n = String(S.evidenceCount).padStart(2,'0');
  const label = kind==='video' ? 'VID' : 'IMG';
  S.evidence.push({id:`${label}_017_${n}`, time:'10:4'+ (S.evidenceCount%10) +' AM'});
  render();
  showToast(t('evidenceCaptured'));
}

function addEvidenceItem(label, thumb){
  S.evidenceCount++;
  const n = String(S.evidenceCount).padStart(2,'0');
  S.evidence.push({id:`${label}_017_${n}`, time:'10:4'+ (S.evidenceCount%10) +' AM', thumb});
  render();
}

function triggerPhotoPicker(){
  const input = document.getElementById('photo-upload-input');
  if(input) input.click();
}

function handlePhotoUpload(event){
  const file = event.target.files && event.target.files[0];
  event.target.value = ''; // allow picking the same file again later
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    addEvidenceItem('IMG', reader.result);
    showToast(t('evidenceUploaded'));
  };
  reader.onerror = () => showToast(t('photoReadError'));
  reader.readAsDataURL(file);
}

function openVoiceModal(){ S.voiceModal = true; render(); }

function closeVoiceModal(){ S.voiceModal = false; render(); }

function saveVoiceNote(){
  S.voiceNote = {duration:'00:18', transcript:t('voiceTranscript')};
  S.voiceModal = false; render();
}

function voiceModal(){
  return `<div class="modal-overlay" onclick="if(event.target===this) closeVoiceModal()">
    <div class="modal-sheet">
      <div class="sheet-handle"></div>
      <h3 style="font-size:16px; margin-bottom:14px;">${t('addVoiceNote')}</h3>
      <div class="card" style="text-align:center; padding:26px 16px;">
        ${waveform()}
        <div style="font-weight:700; margin-top:10px;">00:18</div>
        <div style="font-size:12px; color:var(--muted); margin-top:10px;">"${t('voiceTranscript')}"</div>
      </div>
      <div class="btn-row" style="margin-top:16px;">
        <button class="btn btn-outline" onclick="closeVoiceModal()">${t('cancel')}</button>
        <button class="btn btn-primary" onclick="saveVoiceNote()">${t('saveNote')}</button>
      </div>
    </div>
  </div>`;
}

function waveform(){
  let bars = '';
  for(let i=0;i<28;i++){
    const h = 6 + Math.round(Math.abs(Math.sin(i*0.7))*32);
    bars += `<div class="wf-bar" style="height:${h}px;"></div>`;
  }
  return `<div class="waveform">${bars}</div>`;
}

function voiceNoteCard(){
  return `<div class="card" style="margin-top:16px;">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div style="font-weight:700; font-size:13px;">🎙️ Voice Note · ${S.voiceNote.duration}</div>
      <div style="display:flex; gap:8px;">
        <button class="chip" style="padding:5px 9px;">▶</button>
        <button class="chip" style="padding:5px 9px;" onclick="S.voiceNote=null; render();">🗑</button>
      </div>
    </div>
    <div style="font-size:12px; color:var(--muted); margin-top:8px; font-style:italic;">"${S.voiceNote.transcript}"</div>
  </div>`;
}
