/* data.js
 * Mock data and static configuration: sites, issues, inspectors, form definitions, GPS radius.
 */

const SITES = [
  {id:'SITE-017', name:'Bridge – Site 17', type:'Structural Inspection', location:'Sector 18', priority:'High', due:'Today', status:'Pending', last:'12 August 2026', prevIssues:2, lat:28.6139, lng:77.2090},
  {id:'SITE-024', name:'Road – Site 24', type:'Pavement Inspection', location:'Sector 62', priority:'Medium', due:'Tomorrow', status:'Pending', last:'02 July 2026', prevIssues:0, lat:28.4595, lng:77.0266},
  {id:'SITE-031', name:'Building – Site 31', type:'Facility Inspection', location:'Sector 9', priority:'Low', due:'02 Sep 2026', status:'In Progress', last:'20 June 2026', prevIssues:1, lat:28.5355, lng:77.3910},
  {id:'SITE-008', name:'Water Pipeline – Site 08', type:'Utility Inspection', location:'Sector 41', priority:'Medium', due:'Submitted', status:'Submitted', last:'28 July 2026', prevIssues:1, lat:28.7041, lng:77.1025},
  {id:'SITE-012', name:'Flyover – Site 12', type:'Structural Inspection', location:'Sector 5', priority:'High', due:'Closed', status:'Closed', last:'01 May 2026', prevIssues:3, lat:28.4089, lng:77.3178},
];

const ISSUES = [
  {id:'ISS-1042', title:'Critical Crack', site:'Site 17', severity:'Critical', status:'In Progress', assignee:'Engineer A', due:'05 September 2026'},
  {id:'ISS-1038', title:'Corrosion on railing', site:'Site 12', severity:'High', status:'Assigned', assignee:'Engineer B', due:'10 September 2026'},
  {id:'ISS-1029', title:'Leakage at joint', site:'Site 08', severity:'Medium', status:'Resolved', assignee:'Engineer C', due:'30 August 2026'},
  {id:'ISS-1051', title:'Surface damage', site:'Site 24', severity:'Low', status:'Open', assignee:'Unassigned', due:'—'},
  {id:'ISS-1017', title:'Missing bolt cover', site:'Site 31', severity:'Medium', status:'Verification Required', assignee:'Engineer A', due:'02 September 2026'},
];

const INSPECTORS = [
  {name:'Rahul Sharma', site:'Site 17', status:'Inspecting', update:'2 min ago'},
  {name:'Amit Verma', site:'Site 24', status:'Completed', update:'8 min ago'},
  {name:'Neha Kulkarni', site:'Site 31', status:'Pending', update:'12 min ago'},
  {name:'Suresh Iyer', site:'Site 08', status:'Inspecting', update:'4 min ago'},
];

const GPS_VERIFY_RADIUS_M = 150;

const FORM_FIELDS = {
  'General Condition':['Overall condition','Accessibility','Cleanliness','Safety condition'],
  'Structural Condition':['Cracks','Surface damage','Corrosion','Leakage','Missing components','Other visible defects'],
};

const FORM_SECTION_KEY = {'General Condition':'generalCondition','Structural Condition':'structuralCondition'};

const FORM_FIELD_KEY = {
  'Overall condition':'f_overallCondition','Accessibility':'f_accessibility','Cleanliness':'f_cleanliness','Safety condition':'f_safetyCondition',
  'Cracks':'f_cracks','Surface damage':'f_surfaceDamage','Corrosion':'f_corrosion','Leakage':'f_leakage',
  'Missing components':'f_missingComponents','Other visible defects':'f_otherDefects',
};

const RATING_KEY = {Good:'ratingGood',Fair:'ratingFair',Poor:'ratingPoor',Critical:'ratingCritical'};
