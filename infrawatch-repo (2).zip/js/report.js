/* report.js
 * Review, submission success, report screen, PDF export (jsPDF) and re-inspection.
 */

function integrityRing(pct){
  const r=44, c=2*Math.PI*r, off = c*(1-pct/100);
  return `<div class="ring" style="width:84px;height:84px;">
    <svg width="84" height="84" viewBox="0 0 100 100">
      <circle cx="50" cy="50" r="${r}" stroke="#EDE9FB" stroke-width="9" fill="none"/>
      <circle cx="50" cy="50" r="${r}" stroke="var(--success)" stroke-width="9" fill="none"
        stroke-dasharray="${c}" stroke-dashoffset="${off}" stroke-linecap="round"/>
    </svg>
    <div class="ring-label"><div class="v" style="font-size:17px;">${pct}%</div></div>
  </div>`;
}

function screenReview(){
  const confirmed = S.findings.filter(f=>f.status==='confirmed').length;
  const rejected = S.findings.filter(f=>f.status==='rejected').length;
  const integrityItems = ['chk_gpsVerified','chk_liveEvidence','chk_timestamp','chk_inspectorAuth','chk_evidenceHash','chk_duplicateCheck'];
  return `<div class="screen-body">
    ${header(t('inspectionSummary'), S.activeSite.id, "go('camera')")}
    <div class="content">
      <div class="card">
        <div class="check-row"><span>${t('site')}</span><span style="margin-left:auto; font-weight:700;">${S.activeSite.name}</span></div>
        <div class="check-row"><span>${t('gps')}</span><span style="margin-left:auto;"><span class="badge success">${t('verified')} ✓</span></span></div>
        <div class="check-row"><span>${t('evidence')}</span><span style="margin-left:auto; font-weight:700;">${S.evidence.length} ${t('items')} · ${S.voiceNote?1:0} ${t('voiceNote')}</span></div>
        <div class="check-row"><span>${t('findings')}</span><span style="margin-left:auto; font-weight:700;">${S.findings.length || 1}</span></div>
        <div class="check-row"><span>${t('critical')}</span><span style="margin-left:auto;"><span class="badge critical">1</span></span></div>
        <div class="check-row" style="border-bottom:none;"><span>${t('aiFindings')}</span><span style="margin-left:auto; font-weight:700;">${confirmed||1} ${t('confirmedLabel')} · ${rejected} ${t('rejectedLabel')}</span></div>
      </div>

      <div class="section-label">${t('inspectionIntegrity')}</div>
      <div class="card">
        <div style="display:flex; align-items:center; gap:16px;">
          ${integrityRing(96)}
          <div style="flex:1;">
            ${integrityItems.map(k=>`
              <div class="check-row" style="padding:4px 0;"><div class="check-dot">✓</div>${t(k)}</div>`).join('')}
          </div>
        </div>
        <div style="font-size:11px; color:var(--muted); margin-top:10px;">${t('integrityScoreDesc')}</div>
      </div>
    </div>
    <div class="fab-start">
      <button class="btn btn-primary" onclick="go('success')">${t('submitInspection')}</button>
    </div>
  </div>`;
}

function screenSuccess(){
  return `<div class="screen-body">
    <div class="content" style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; text-align:center; gap:14px;">
      <div style="width:70px;height:70px;border-radius:50%;background:var(--success-bg); display:flex;align-items:center;justify-content:center; font-size:32px; color:var(--success);">✓</div>
      <h2 style="font-size:18px;">${t('submittedSuccessfully')}</h2>
      <div class="card" style="width:100%;">
        <div class="check-row"><span>${t('inspectionId')}</span><span style="margin-left:auto; font-weight:800;">INS-2026-01742</span></div>
        <div class="check-row" style="border-bottom:none;"><span>${t('statusLabel')}</span><span style="margin-left:auto;"><span class="badge info">${t('submitted')}</span></span></div>
      </div>
      <div style="width:100%; text-align:left;">
        <div class="check-row"><div class="check-dot">✓</div>${t('gpsVerifiedChk')}</div>
        <div class="check-row"><div class="check-dot">✓</div>${t('evidenceUploadedChk')}</div>
        <div class="check-row"><div class="check-dot">✓</div>${t('aiAnalysisCompleted')}</div>
        <div class="check-row" style="border-bottom:none;"><div class="check-dot">✓</div>${t('reportGenerated')}</div>
      </div>
      <div class="btn-row" style="width:100%; margin-top:10px;">
        <button class="btn btn-outline" onclick="go('report')">${t('viewReport')}</button>
        <button class="btn btn-primary" onclick="backToDashboard()">${t('dashboard')}</button>
      </div>
    </div>
  </div>`;
}

function backToDashboard(){
  S.aiAnalyzed=false; S.pendingFinding=null;
  setNavTab('home');
}

function screenReport(){
  return `<div class="screen-body">
    ${header(t('inspectionReport'), 'INS-2026-01742', "go('success')")}
    <div class="content">
      <div class="card" style="text-align:center; padding:20px;">
        <div style="font-weight:800; letter-spacing:.5px; font-size:13px; color:var(--muted);">${t('smartInspectionReport')}</div>
        <div style="font-size:18px; font-weight:800; margin-top:6px;">${S.activeSite.name}</div>
        <div style="font-size:12px; color:var(--muted); margin-top:2px;">${S.activeSite.id} · 03 September 2026, 10:32 AM</div>
      </div>
      ${reportRow(t('rep_inspector'),'Rahul Sharma · EMP-2291')}
      ${reportRow(t('rep_gpsCoordinates'),`28.6139° N, 77.2090° E · ${t('verified')}`)}
      ${reportRow(t('rep_checklistCompletion'),`10 / 10 ${t('items')}`)}
      ${reportRow(t('rep_aiFindings'),`${t('surfaceCrack')} (91%) · ${t('confirmedLabel')}`)}
      ${reportRow(t('rep_severity'), severityLabel('High').toUpperCase())}
      ${reportRow(t('rep_evidence'),`${S.evidence.length} · ${S.voiceNote?1:0} ${t('voiceNote')}`)}
      ${reportRow(t('rep_recommendation'), t('scheduleTechnical'))}
      ${reportRow(t('rep_issueStatus'),`${t('assignedTo')} Engineer A`)}
      ${reportRow(t('rep_integrityScore'),'96%')}
    </div>
    <div class="fab-start">
      <div class="btn-row">
        <button class="btn btn-outline" onclick="downloadInspectionReportPdf()">${t('generatePdf')}</button>
        <button class="btn btn-primary" onclick="downloadInspectionReportPdf()">${t('download')}</button>
      </div>
    </div>
  </div>`;
}

function downloadInspectionReportPdf(){
  // Note: the PDF itself is always generated in English — the PDF library's built-in
  // font can't render Devanagari (Hindi) glyphs, so a Hindi PDF would show blank boxes.
  const rows = [
    ['Site', S.activeSite ? S.activeSite.name : '—'],
    ['Site ID', S.activeSite ? S.activeSite.id : '—'],
    ['Date / Time', '03 September 2026, 10:32 AM'],
    ['Inspector', 'Rahul Sharma · EMP-2291'],
    ['GPS Coordinates', '28.6139° N, 77.2090° E · Verified'],
    ['Checklist Completion', '10 / 10 items'],
    ['AI Findings', 'Surface Crack (91%) · Confirmed'],
    ['Severity', 'HIGH'],
    ['Evidence', `${S.evidence.length} photos/videos · ${S.voiceNote?1:0} voice note`],
    ['Recommendation', 'Schedule detailed technical inspection'],
    ['Issue Status', 'Assigned to Engineer A'],
    ['Integrity Score', '96%'],
  ];
  buildAndDownloadPdf('INFRAWATCH REPORT', 'INS-2026-01742', rows, `Inspection_Report_${S.activeSite?S.activeSite.id:'report'}.pdf`);
  showToast(t('reportDownloaded'));
}

function buildAndDownloadPdf(title, subtitle, rows, filename){
  if(!window.jspdf){ showToast('PDF library failed to load'); return; }
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit:'pt', format:'a4' });
  const marginX = 48;
  let y = 60;
  doc.setFont('helvetica','bold'); doc.setFontSize(16);
  doc.text(title, marginX, y); y += 20;
  doc.setFont('helvetica','normal'); doc.setFontSize(11); doc.setTextColor(90);
  doc.text(subtitle, marginX, y); y += 26;
  doc.setDrawColor(225); doc.line(marginX, y, 548, y); y += 22;
  doc.setTextColor(20);
  rows.forEach(([label, value])=>{
    doc.setFont('helvetica','bold'); doc.setFontSize(10.5);
    doc.text(String(label), marginX, y);
    doc.setFont('helvetica','normal');
    const valueLines = doc.splitTextToSize(String(value), 300);
    doc.text(valueLines, 300, y);
    y += 18 * valueLines.length;
    if(y > 760){ doc.addPage(); y = 60; }
  });
  y += 20;
  doc.setFontSize(9); doc.setTextColor(140);
  doc.text('Generated by InfraWatch · ' + new Date().toLocaleString(), marginX, y);
  doc.save(filename);
}

function reportRow(l,v){
  return `<div class="check-row"><span style="color:var(--muted);">${l}</span><span style="margin-left:auto; font-weight:700; text-align:right;">${v}</span></div>`;
}

function screenReinspect(){
  return `<div class="screen-body">
    ${header(t('reinspection'), S.activeSite.id, "go('siteDetail')")}
    <div class="content">
      <div class="section-label">${t('previousFinding')}</div>
      <div class="card">
        <div class="check-row"><span>${t('defectLabel')}</span><span style="margin-left:auto; font-weight:700;">${t('surfaceCrack')}</span></div>
        <div class="check-row"><span>${t('severity')}</span><span style="margin-left:auto;"><span class="badge high">${severityLabel('High')}</span></span></div>
        <div class="check-row" style="border-bottom:none;"><span>${t('statusLabel')}</span><span style="margin-left:auto;"><span class="badge success">${t('repairCompleted')}</span></span></div>
      </div>

      <div class="section-label">${t('beforeAfter')}</div>
      <div class="before-after">
        <div class="ba-box"><div class="ba-img"></div><div class="ba-label">${t('before')}</div></div>
        <div class="ba-box"><div class="ba-img" style="background:linear-gradient(155deg,#123B2C,#0A1F18);"></div><div class="ba-label">${t('after')}</div></div>
      </div>

      <div class="field" style="margin-top:16px;"><label>${t('remarks')}</label><textarea rows="3" placeholder="${t('confirmResolutionPh')}"></textarea></div>
      <button class="chip">${t('captureNewPhoto')}</button>
    </div>
    <div class="fab-start">
      <button class="btn btn-primary" onclick="showToast(t('resolutionVerified'))">${t('verifyResolution')}</button>
    </div>
  </div>`;
}
