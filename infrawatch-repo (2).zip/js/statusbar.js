/* statusbar.js
 * Phone status bar: real India time and real battery level (where the browser supports it).
 */

function updateStatusClock(){
  const nowIST = new Intl.DateTimeFormat('en-IN', {
    timeZone:'Asia/Kolkata', hour:'numeric', minute:'2-digit', hour12:true
  }).format(new Date());
  const text = nowIST.replace(/\s?(am|pm)/i, m => m.trim().toLowerCase());
  document.querySelectorAll('.statusbar-clock').forEach(el=>{ el.textContent = text; });
}

function renderBatteryIcon(level, charging){
  const pct = Math.round(level * 100);
  const text = `${charging ? '⚡' : '🔋'}${pct}%`;
  document.querySelectorAll('.statusbar-battery').forEach(el=>{ el.textContent = text; });
}

function initStatusBar(){
  updateStatusClock();
  setInterval(updateStatusClock, 1000);

  if(navigator.getBattery){
    navigator.getBattery().then(battery=>{
      const update = () => renderBatteryIcon(battery.level, battery.charging);
      update();
      battery.addEventListener('levelchange', update);
      battery.addEventListener('chargingchange', update);
    }).catch(()=>{
      document.querySelectorAll('.statusbar-battery').forEach(el=>{ el.textContent = '🔋'; });
    });
  }
  // Battery Status API isn't available in this browser (e.g. iOS Safari) — the
  // icon stays a plain 🔋 with no invented percentage rather than a fake number.
}
