# InfraWatch

A clickable prototype of a real-time infrastructure inspection platform, with two sides:

- **Inspector app** (phone-style UI): check in at a site, verify location, capture evidence, fill in the inspection checklist and export a PDF report.
- **Admin Command Center**: live site map, KPIs, inspector activity, issues, analytics and reports.

It is plain HTML, CSS and JavaScript. There is no build step and no backend: open `index.html` and it runs.

**Live demo:** `https://<your-username>.github.io/infrawatch/`

---

## About this project

> **TODO (write this in your own words, 3–5 sentences):**
> What problem were you trying to solve? Who would use this (site inspectors, city engineers, contractors)?
> What did you want to learn or show by building it? Why these features?

## What's real and what's mock

| Real (works on your device) | Mock / simulated |
|---|---|
| GPS check-in: reads your actual location and measures the distance to the site | Sites, inspectors, issues, KPIs and chart numbers |
| QR scanning with the camera, or from an uploaded / photographed QR image | The AI defect analysis (always reports the same finding) |
| Photo capture from the live camera, or picking a photo from your device | Voice notes (a fixed 18-second sample, nothing is recorded) |
| PDF report export | Login (any non-empty email and password is accepted) |
| Live site map for admins | Offline mode (a toggle that simulates syncing) |
| Profile edits, photo, dark mode and language, saved in your browser | Values inside the PDF report such as date and inspector |

See [docs/LIMITATIONS.md](docs/LIMITATIONS.md) for the full list and next steps.

## Features

**Inspector**
- Role selection (Inspector or Admin), then login with basic field checks
- Today's tasks, inspection list, issues and notifications
- Site detail with QR scan and GPS verification (must be within 150 m of the site)
- Evidence capture, simulated AI analysis, defect details, inspection checklist, review and submit
- PDF report download
- Profile: editable name, phone, email and photo; badges; recent activity; language, notifications and dark mode settings
- English and Hindi

**Admin**
- Dashboard with KPIs and a live monitoring map (one pin per site, coloured by status)
- Inspectors, issues (filter and assign), analytics (date ranges) and reports (PDF)

## Demo accounts

Use the "Use" button on the login screen, or type any email and password.

| Role | Email |
|------|-------|
| Inspector | demo.inspector@example.com |
| Admin | demo.admin@example.com |

## Run it

**Locally:** open `index.html` in a browser. The camera and location features need a secure context (an `https://` page or `localhost`). If your browser blocks them when opening the file directly, serve the folder with any static server, for example:

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

**On GitHub Pages:** push the repo, then go to **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, and save.

## Project structure

```
index.html            page skeleton; loads the CSS and JS below
css/                  tokens, layout, components, admin, profile, dark mode, responsive
  vendor/leaflet.css  Leaflet's stylesheet (third party)
js/                   one file per area of the app (see docs/ARCHITECTURE.md)
docs/                 architecture, how each feature works, limitations
```

## Documentation

- [Architecture](docs/ARCHITECTURE.md): how the app is organised and how rendering works
- [How it works](docs/HOW_IT_WORKS.md): a walkthrough of each feature
- [Limitations and next steps](docs/LIMITATIONS.md)

## Built with

HTML, CSS and vanilla JavaScript. [Leaflet](https://leafletjs.com) for maps (tiles from Esri, with OpenStreetMap as a fallback), [jsQR](https://github.com/cozmo/jsQR) for decoding QR codes, [jsPDF](https://github.com/parallax/jsPDF) for PDF reports. Fonts: Inter and Plus Jakarta Sans.

## Acknowledgements

This project was built with AI assistance (Claude, by Anthropic).

> **TODO:** edit this line so it describes how you actually worked, for example what you decided, what you tested and what you changed.
