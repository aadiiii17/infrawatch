# Architecture

InfraWatch is a small single-page app written with plain JavaScript. There is no framework and no build tool. This document explains how it is put together.

## The core idea: state in, HTML out

All app data lives in one global object, `S`, defined in `js/state.js`. Every screen is a function that reads `S` and returns an HTML string. To change what is on screen you update `S` and call `render()`.

```
user action  →  change S  →  render()  →  screen function returns HTML  →  innerHTML replaces the screen
```

`render()` (in `js/core.js`) works in two modes:

- **Inspector mode:** calls `renderInspector()`, which uses `S.screen` to pick a screen function (`screenDashboard`, `screenGPS`, `screenForm`, …) and writes the result into `#phone-screen`.
- **Admin mode:** calls `renderAdmin()` and writes into `#admin-phone-screen`.

Because the whole screen is re-drawn on each render, some screens need extra setup after the HTML exists. `render()` handles that, for example by starting the map (`initGpsMap`) or the camera (`initCameraPreview`) right after the screen is drawn.

## Files

Scripts are plain `<script>` tags that share one global scope, so they must load in this order (it is set in `index.html`):

| File | Responsibility |
|------|----------------|
| `data.js` | Mock data (sites, issues, inspectors), checklist definitions, GPS radius |
| `state.js` | The global state object `S` |
| `i18n.js` | English and Hindi strings (`T`) and the `t(key)` lookup |
| `core.js` | `render()`, navigation (`go`, `setNavTab`), app-mode switch, toasts |
| `statusbar.js` | Phone status bar: India time and battery level |
| `auth.js` | Splash, role picker, Inspector login |
| `inspector.js` | Inspector shell, dashboard, site list and detail, issues, notifications |
| `gps.js` | GPS verification screen, real geolocation request, Haversine distance |
| `maps.js` | Leaflet maps (GPS check-in map and admin live map) and tile setup |
| `evidence.js` | Live camera, photo capture and upload, voice note modal |
| `ai.js` | Simulated AI analysis, defect details, saving findings |
| `form.js` | Inspection checklist |
| `report.js` | Review, success, report screens and PDF export |
| `scanner.js` | QR scanner modal (camera or image upload) |
| `profile.js` | Profile screen, editing, photo, settings, saving to local storage |
| `admin.js` | Admin login, dashboard, inspectors, issues, analytics, reports |
| `main.js` | Entry point; loaded last |

The `main.js` file runs four lines: load saved profile settings, set the starting mode, render, and start the status bar.

## Styling

CSS is split by purpose and loaded in cascade order: `tokens.css` (colours, radii, shadows as CSS variables) → `layout.css` → `components.css` → `admin.css` → `profile.css` → `dark.css` → `responsive.css`.

Colours come from variables in `:root`. **Dark mode** works by adding the class `dark` to `<body>`, which redefines those variables in `dark.css`; components then pick up the new values without changes.

## Internationalisation

All user-facing text goes through `t('key')`, which looks up `T[S.lang][key]`. Switching language sets `S.lang` and re-renders. The PDF is always generated in English because the built-in PDF font cannot draw Devanagari characters.

## Persistence

Only profile data, notification setting, dark mode and language are saved, in the browser's `localStorage` under the key `infrawatch.profile`. Everything else resets on reload.

## External services

| What | Used for | Note |
|------|----------|------|
| Leaflet (CDN) | Interactive maps | |
| Esri World Street Map tiles | Map background | Falls back to OpenStreetMap if tiles fail repeatedly |
| jsQR (CDN) | Decoding QR codes from camera frames or images | |
| jsPDF (CDN) | PDF reports | |
| Google Fonts | Inter, Plus Jakarta Sans | |

## Adding a new screen

1. Write ``function screenMyThing(){ return `...`; }`` in the relevant file.
2. Add a `case 'myThing':` to the switch in `renderInspector()` (or the admin equivalent).
3. Navigate to it with `go('myThing')`.
4. Add any new text to both languages in `i18n.js`.
