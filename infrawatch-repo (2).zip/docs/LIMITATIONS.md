# Limitations and next steps

This is a prototype built to demonstrate a flow and a design. It is not production software.

## Known limitations

**Data and backend**
- There is no backend or database. Sites, inspectors, issues, KPIs and chart values are hard-coded sample data.
- Login does not authenticate anyone. Any non-empty email and password is accepted.
- Inspection data is not saved. Reloading the page clears everything except profile settings.
- Evidence file names and some PDF values (date, inspector, coordinates, integrity score) are fixed sample text rather than values from the session.

**Simulated features**
- AI defect analysis always returns the same result.
- Voice notes do not record audio.
- Offline mode does not queue or sync data.
- Notifications and activity feed are static.

**Real features with caveats**
- Camera and location need a secure context (HTTPS or localhost) and the user's permission. They are blocked inside embedded preview frames.
- A scanned QR code is not validated against the selected site.
- GPS accuracy depends on the device; indoors the reading can be well off.
- Map tiles depend on third-party servers (Esri, with OpenStreetMap as fallback), which may rate-limit or change their terms. Libraries load from CDNs, so the app needs an internet connection for maps, PDFs and QR decoding.
- The PDF is English only (the built-in font cannot render Hindi).

**Code**
- State is one global object and screens re-render by replacing `innerHTML`. That is simple but would not scale; a framework or a small store would help.
- Scripts share the global scope instead of using ES modules.
- A few state fields (for example `aiAnalyzed`, `qrPayload`, `pendingFinding`) are created on the fly instead of being declared up front in `state.js`.
- A couple of helpers are leftovers (`esc` does nothing, `showToastQuick` is empty).
- There are no automated tests.
- Accessibility has not been audited (keyboard navigation, screen-reader labels, contrast checks).

## Ideas for next steps

1. Add a real backend (for example Firebase or Supabase) for authentication, sites, inspections and evidence storage.
2. Validate scanned QR codes against the assigned site.
3. Replace the simulated AI step with a real image-analysis service.
4. Queue submissions while offline and sync when the connection returns (service worker + IndexedDB).
5. Record real voice notes with the MediaRecorder API.
6. Generate reports from real session data in both languages.
7. Convert to ES modules or a framework and add tests.
8. Run an accessibility pass and test on more devices.
