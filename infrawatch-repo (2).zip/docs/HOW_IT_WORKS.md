# How each feature works

A plain-language walkthrough, useful when explaining the project or answering questions about it.

## Role selection and login
The first screen asks whether you are an Inspector or an Admin (`rolePicker` in `auth.js`). Your choice is stored in `S.loginRole` and decides which login form appears. The Log In button checks that email and password are not empty and accepts anything else. This is a prototype, so there is no real authentication. The "Use" buttons skip the form for the demo accounts.

## GPS verification
When you open the GPS screen, `requestGpsLocation()` (`gps.js`) asks the browser for your position using `navigator.geolocation`. It then measures the distance between you and the site using the Haversine formula, which computes the straight-line distance between two latitude/longitude points on a sphere. If the distance is within 150 m (`GPS_VERIFY_RADIUS_M`), the status becomes "Location verified" and the Start Inspection button is enabled. If permission is denied, the request times out, or the page runs inside an embedded frame, the screen shows a message and a retry button instead.

## Maps
Both maps use Leaflet (`maps.js`). The check-in map shows the site, a circle for the allowed radius, and your position once known. The admin map shows one pin per site, coloured by status, with a popup on tap. `addBaseTiles()` loads Esri street tiles and switches to OpenStreetMap if tiles keep failing. Tiles are only requested up to a zoom level where data exists (`maxNativeZoom`) and are enlarged beyond that.

## QR scanning
The scanner (`scanner.js`) opens the camera, copies video frames onto a hidden canvas about every animation frame and passes the pixels to jsQR. When a code is found, the site is marked as identified and the decoded text is shown. If the camera is blocked or unavailable, the same decoder works on a photo you take or upload, which is the more reliable path on some phones and in embedded previews. The decoded text is not checked against the site, so any QR code counts.

## Evidence capture
`screenCamera` shows a live camera preview (`getUserMedia`). Capturing draws the current video frame onto a canvas and stores it as an image. If the camera is not available, the button falls back to the device's file picker. Photos are held in memory as data URLs.

## AI analysis
This is simulated. `screenAI` runs a short scanning animation and then presents a fixed finding (a surface crack, 91% confidence). The inspector can confirm, edit or reject it. If a real photo was captured, that photo is shown behind the result.

## Checklist, review and report
The checklist answers are stored in `S.formAnswers`. The review screen summarises evidence and findings, and shows an integrity score ring. The PDF is built in the browser with jsPDF from a list of label/value rows.

## Offline mode
The toggle only changes `S.offline` to show a banner and, when switched back on, shows a short "syncing" state followed by a confirmation. No data is actually queued.

## Profile
You can edit name, phone and email (validated before saving), change or remove your photo (cropped to a square and resized to 256 px before saving), switch language, toggle notifications and dark mode. These are saved to `localStorage`, so they survive a reload.

## Admin Command Center
Admin screens are in `admin.js`. The dashboard shows KPI cards, a live map and field activity. Issues can be filtered and assigned, analytics has date ranges and a bar chart, and reports can be exported as PDF. The numbers are mock data defined in the code.

## Status bar
The clock uses the Asia/Kolkata time zone and updates every second. The battery percentage comes from the Battery Status API where the browser supports it; otherwise it shows a plain battery icon.
